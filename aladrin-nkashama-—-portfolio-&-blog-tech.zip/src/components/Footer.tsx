import React from 'react';
import { PERSONAL_INFO } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { ArrowUp, Mail, Phone, ShoppingBag, Youtube, Facebook, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onOpenCvModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCvModal }) => {
  const { theme } = useTheme();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      className={`border-t text-xs py-14 transition-colors ${
        theme === 'dark'
          ? 'bg-[#05060a] border-slate-800 text-slate-400'
          : 'bg-slate-900 border-slate-800 text-slate-400'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-slate-800/80">
          
          {/* Brand & Mission Statement (5 cols) */}
          <div className="md:col-span-5 space-y-3">
            <div className="text-base font-extrabold text-white tracking-wide uppercase font-display">
              {PERSONAL_INFO.name}
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Ingénieur Informaticien spécialisé en modélisation de bases de données, sécurité des systèmes, cartographie SIG et optimisation documentaire.
            </p>
            <div className="text-slate-500 font-mono text-[11px] pt-1">
              Kinshasa, République Démocratique du Congo
            </div>
          </div>

          {/* Navigation Links (3 cols) */}
          <div className="md:col-span-3 space-y-2.5">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Navigation
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#about" className="hover:text-blue-400 transition-colors">
                  Présentation & Biographie
                </a>
              </li>
              <li>
                <a href="#competences" className="hover:text-blue-400 transition-colors">
                  Compétences & Technologies
                </a>
              </li>
              <li>
                <a href="#parcours" className="hover:text-blue-400 transition-colors">
                  Parcours & Certifications
                </a>
              </li>
              <li>
                <a href="#blog" className="hover:text-blue-400 transition-colors">
                  Blog & Publications Techniques
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenCvModal}
                  className="text-blue-400 hover:underline font-semibold cursor-pointer"
                >
                  Télécharger le CV officiel
                </button>
              </li>
            </ul>
          </div>

          {/* Channels & Store (4 cols) */}
          <div className="md:col-span-4 space-y-2.5">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Plateformes & Contact
            </div>
            <div className="space-y-2 text-xs">
              <div>
                <a
                  href={`mailto:${PERSONAL_INFO.email}`}
                  className="hover:text-blue-400 transition-colors flex items-center gap-2"
                >
                  <Mail className="w-3.5 h-3.5 text-blue-400" />
                  <span>{PERSONAL_INFO.email}</span>
                </a>
              </div>
              <div>
                <a
                  href={`tel:${PERSONAL_INFO.phones[0].replace(/\s+/g, '')}`}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-2 font-mono"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{PERSONAL_INFO.phones[0]}</span>
                </a>
              </div>
              <div className="pt-2 flex flex-wrap gap-2">
                <a
                  href={PERSONAL_INFO.shopUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-all font-medium"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                  <span>Boutique Chariow</span>
                </a>
                <a
                  href={PERSONAL_INFO.youtubeChannels[0].url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-all font-medium"
                >
                  <Youtube className="w-3.5 h-3.5 text-red-500" />
                  <span>AladArttech</span>
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-[11px] text-slate-500">
            © 2026 Aladrin Nkashama. Tous droits réservés. Portfolio & Blog professionnel officiel.
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <span>Haut de page</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
