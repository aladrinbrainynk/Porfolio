import React from 'react';
import { PERSONAL_INFO } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { Download, ArrowRight, ShoppingBag, Youtube, Facebook, ShieldCheck, Database, Award, MapPin, CheckCircle2, Cpu, Globe, Server, Terminal } from 'lucide-react';

interface HeroProps {
  onOpenCvModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenCvModal }) => {
  const { theme } = useTheme();

  return (
    <section
      id="about"
      className={`relative pt-28 pb-16 sm:pt-36 sm:pb-24 overflow-hidden ${
        theme === 'dark' ? 'bg-[#090b12]' : 'bg-[#f8fafc]'
      }`}
    >
      {/* Background Mesh Gradients */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-gradient-to-tr from-blue-600/15 via-indigo-500/10 to-transparent blur-[140px] rounded-full pointer-events-none" />
      <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Typographic & Profile Info (7 cols on desktop) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Availability status badge */}
            <div
              className={`inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full text-xs font-medium border shadow-xs ${
                theme === 'dark'
                  ? 'bg-slate-900/90 border-slate-700/80 text-slate-300'
                  : 'bg-white border-slate-200 text-slate-700 shadow-sm'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-semibold text-emerald-500">Disponible</span>
              <span className="text-slate-400">·</span>
              <span>Postes & Missions Techniques</span>
              <span className="text-slate-400">·</span>
              <span className="text-blue-500 font-medium">Kinshasa & Mobilité</span>
            </div>

            {/* Display Headline */}
            <div className="space-y-3">
              <h1
                className={`text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] font-display text-balance ${
                  theme === 'dark' ? 'text-white' : 'text-slate-950'
                }`}
              >
                Ingénieur Informaticien & Expert Bases de Données
              </h1>
              <p className="text-lg sm:text-xl font-semibold text-blue-500 flex items-center flex-wrap gap-2">
                <span>Aladrin Nkashama</span>
                <span className="text-slate-400 font-normal">|</span>
                <span className={theme === 'dark' ? 'text-slate-300 font-normal' : 'text-slate-600 font-normal'}>
                  Systèmes d'Information · Rigueur & Optimisation
                </span>
              </p>
            </div>

            {/* Authentic bio from CV */}
            <p
              className={`text-base sm:text-lg leading-relaxed max-w-2xl ${
                theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
              }`}
            >
              {PERSONAL_INFO.aboutText[0]} {PERSONAL_INFO.aboutText[1]}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <button
                onClick={onOpenCvModal}
                className="flex items-center gap-2.5 px-6 py-3.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-lg shadow-blue-600/30 transition-all duration-150 cursor-pointer hover:scale-[1.02]"
              >
                <Download className="w-4 h-4" />
                <span>Télécharger le CV officiel</span>
              </button>

              <a
                href="#competences"
                className={`flex items-center gap-2 px-5 py-3.5 text-sm font-semibold rounded-xl border transition-all ${
                  theme === 'dark'
                    ? 'bg-slate-900/90 hover:bg-slate-800 text-slate-200 border-slate-700 hover:border-slate-600'
                    : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300 shadow-sm'
                }`}
              >
                <span>Explorer mes compétences</span>
                <ArrowRight className="w-4 h-4 text-blue-500" />
              </a>

              <a
                href="#contact"
                className={`px-4 py-3.5 text-sm font-medium transition-colors ${
                  theme === 'dark'
                    ? 'text-slate-400 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Prendre contact &rarr;
              </a>
            </div>

            {/* Direct channels & boutique links */}
            <div
              className={`pt-5 border-t ${
                theme === 'dark' ? 'border-slate-800/80' : 'border-slate-200'
              }`}
            >
              <div
                className={`text-xs uppercase tracking-wider font-bold mb-3 ${
                  theme === 'dark' ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                Canaux & Réseaux Professionnels
              </div>
              <div className="flex flex-wrap items-center gap-2.5 text-xs">
                <a
                  href={PERSONAL_INFO.shopUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all font-medium ${
                    theme === 'dark'
                      ? 'bg-slate-900/80 border-slate-700 hover:border-amber-400 text-slate-200 hover:text-amber-300'
                      : 'bg-white border-slate-300 hover:border-amber-500 text-slate-700 hover:text-amber-600 shadow-xs'
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-500" />
                  <span>Boutique Chariow</span>
                </a>

                {PERSONAL_INFO.youtubeChannels.map((yt) => (
                  <a
                    key={yt.name}
                    href={yt.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all font-medium ${
                      theme === 'dark'
                        ? 'bg-slate-900/80 border-slate-700 hover:border-red-500 text-slate-200 hover:text-red-400'
                        : 'bg-white border-slate-300 hover:border-red-500 text-slate-700 hover:text-red-600 shadow-xs'
                    }`}
                  >
                    <Youtube className="w-3.5 h-3.5 text-red-500" />
                    <span>{yt.name}</span>
                  </a>
                ))}

                <a
                  href={PERSONAL_INFO.facebookProfile}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all font-medium ${
                    theme === 'dark'
                      ? 'bg-slate-900/80 border-slate-700 hover:border-blue-500 text-slate-200 hover:text-blue-400'
                      : 'bg-white border-slate-300 hover:border-blue-500 text-slate-700 hover:text-blue-600 shadow-xs'
                  }`}
                >
                  <Facebook className="w-3.5 h-3.5 text-blue-500" />
                  <span>Facebook</span>
                </a>
              </div>
            </div>

            {/* Key Stats Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 pt-2">
              {PERSONAL_INFO.stats.map((stat, i) => (
                <div
                  key={i}
                  className={`p-3.5 rounded-2xl border transition-colors ${
                    theme === 'dark'
                      ? 'bg-slate-900/60 border-slate-800'
                      : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div
                    className={`text-2xl font-extrabold font-mono tabular-nums ${
                      theme === 'dark' ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {stat.value}
                  </div>
                  <div
                    className={`text-xs mt-1 font-medium ${
                      theme === 'dark' ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* Right Column: Architectural Engineering Identity Console (No Photo) */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-md">
              {/* Outer decorative gradient border */}
              <div className="absolute -inset-1.5 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-3xl blur-md opacity-30" />
              
              {/* Card Container */}
              <div
                className={`relative rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 ${
                  theme === 'dark'
                    ? 'bg-[#0f121d] border-slate-800'
                    : 'bg-white border-slate-200'
                }`}
              >
                
                {/* Header of Console: Monogram & Verification Badge */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
                  <div className="flex items-center gap-3">
                    {/* Monogram Seal */}
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-extrabold font-mono text-lg shadow-md shadow-blue-600/30">
                      AN
                    </div>
                    <div>
                      <div className={`font-extrabold text-sm sm:text-base font-display ${
                        theme === 'dark' ? 'text-white' : 'text-slate-900'
                      }`}>
                        ALADRIN NKASHAMA
                      </div>
                      <div className="text-xs text-blue-500 font-semibold">
                        Ingénieur Informaticien
                      </div>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-[11px] font-semibold px-2.5 py-1 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Profil Vérifié</span>
                  </span>
                </div>

                {/* Key Technical Poles Breakdown */}
                <div className="space-y-3">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Pôles d'Intervention Clés :
                  </div>

                  <div className="space-y-2">
                    <div
                      className={`p-3 rounded-xl border flex items-center gap-3 ${
                        theme === 'dark'
                          ? 'bg-slate-900/80 border-slate-800 text-slate-200'
                          : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-blue-600/15 text-blue-500 flex items-center justify-center shrink-0">
                        <Database className="w-4 h-4" />
                      </div>
                      <div className="text-xs">
                        <strong className="block font-semibold">Bases de Données & Systèmes</strong>
                        <span className="text-slate-500 text-[11px]">Administration relationnelle, GED, archivage</span>
                      </div>
                    </div>

                    <div
                      className={`p-3 rounded-xl border flex items-center gap-3 ${
                        theme === 'dark'
                          ? 'bg-slate-900/80 border-slate-800 text-slate-200'
                          : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-emerald-600/15 text-emerald-500 flex items-center justify-center shrink-0">
                        <Terminal className="w-4 h-4" />
                      </div>
                      <div className="text-xs">
                        <strong className="block font-semibold">Cybersécurité & Hacking Éthique</strong>
                        <span className="text-slate-500 text-[11px]">Audit réseau, tests d'intrusion, cryptographie</span>
                      </div>
                    </div>

                    <div
                      className={`p-3 rounded-xl border flex items-center gap-3 ${
                        theme === 'dark'
                          ? 'bg-slate-900/80 border-slate-800 text-slate-200'
                          : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-amber-600/15 text-amber-500 flex items-center justify-center shrink-0">
                        <Globe className="w-4 h-4" />
                      </div>
                      <div className="text-xs">
                        <strong className="block font-semibold">Cartographie Numérique & SIG</strong>
                        <span className="text-slate-500 text-[11px]">Géoréférencement RGPH-2, sondages aréolaires</span>
                      </div>
                    </div>

                    <div
                      className={`p-3 rounded-xl border flex items-center gap-3 ${
                        theme === 'dark'
                          ? 'bg-slate-900/80 border-slate-800 text-slate-200'
                          : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-lg bg-indigo-600/15 text-indigo-500 flex items-center justify-center shrink-0">
                        <Cpu className="w-4 h-4" />
                      </div>
                      <div className="text-xs">
                        <strong className="block font-semibold">Hardware & Maintenance Mobile</strong>
                        <span className="text-slate-500 text-[11px]">Diagnostic carte mère, flash firmware, décodage</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Profile quick specs in bento grid style */}
                <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                  <div
                    className={`p-3 rounded-xl border ${
                      theme === 'dark'
                        ? 'bg-slate-900/80 border-slate-800 text-slate-300'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="block text-[11px] text-slate-500 font-medium">Poste Actuel</span>
                    <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                      Logisticien @ ADPS
                    </strong>
                  </div>

                  <div
                    className={`p-3 rounded-xl border ${
                      theme === 'dark'
                        ? 'bg-slate-900/80 border-slate-800 text-slate-300'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="block text-[11px] text-slate-500 font-medium">Diplôme Supérieur</span>
                    <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                      Graduat G3 ISC
                    </strong>
                  </div>
                </div>

                {/* Direct action button */}
                <button
                  onClick={onOpenCvModal}
                  className={`w-full py-3.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                    theme === 'dark'
                      ? 'bg-slate-800 hover:bg-slate-700 text-white border-slate-700'
                      : 'bg-slate-900 hover:bg-slate-800 text-white border-slate-900'
                  }`}
                >
                  <Download className="w-4 h-4 text-blue-400" />
                  <span>Consulter & Télécharger le CV Officiel</span>
                </button>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
