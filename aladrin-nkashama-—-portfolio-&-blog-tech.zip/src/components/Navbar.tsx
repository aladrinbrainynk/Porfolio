import React, { useState, useEffect } from 'react';
import { PERSONAL_INFO } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { Menu, X, Download, Sun, Moon, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenCvModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCvModal }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'À Propos', href: '#about' },
    { label: 'Compétences', href: '#competences' },
    { label: 'Parcours', href: '#parcours' },
    { label: 'Blog & Articles', href: '#blog' },
    { label: 'Références', href: '#references' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-200 ${
        isScrolled
          ? theme === 'dark'
            ? 'bg-[#090b12]/90 backdrop-blur-md border-b border-slate-800/80 shadow-xl'
            : 'bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a
          href="#"
          className={`text-lg sm:text-xl font-extrabold tracking-tight uppercase font-display transition-colors ${
            theme === 'dark'
              ? 'text-white hover:text-blue-400'
              : 'text-slate-900 hover:text-blue-600'
          }`}
        >
          {PERSONAL_INFO.name}
        </a>

        {/* Zone 2: Navigation Links (Clean text links with hover) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`py-1 relative transition-colors after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-blue-500 hover:after:w-full after:transition-all after:duration-200 ${
                theme === 'dark'
                  ? 'text-slate-300 hover:text-blue-400'
                  : 'text-slate-600 hover:text-blue-600'
              }`}
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary Actions + Theme Switcher */}
        <div className="hidden sm:flex items-center gap-3">
          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-xl transition-all duration-150 cursor-pointer flex items-center gap-1.5 text-xs font-medium border ${
              theme === 'dark'
                ? 'bg-slate-900 text-amber-300 hover:text-white hover:bg-slate-800 border-slate-800'
                : 'bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200 border-slate-300'
            }`}
            title={theme === 'dark' ? 'Passer au mode clair' : 'Passer au mode sombre'}
            aria-label="Basculer le thème visuel"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="hidden xl:inline text-slate-300">Clair</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-indigo-600" />
                <span className="hidden xl:inline text-slate-600">Sombre</span>
              </>
            )}
          </button>

          {/* Download CV CTA */}
          <button
            onClick={onOpenCvModal}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md shadow-blue-600/25 transition-all duration-150 whitespace-nowrap cursor-pointer hover:scale-[1.02]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Télécharger CV</span>
          </button>

          <a
            href="#contact"
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap ${
              theme === 'dark'
                ? 'text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border-slate-700/80'
                : 'text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border-slate-300'
            }`}
          >
            Me Contacter
          </a>
        </div>

        {/* Mobile menu and theme toggle */}
        <div className="flex items-center gap-2 sm:hidden">
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-lg border ${
              theme === 'dark'
                ? 'bg-slate-900 text-amber-400 border-slate-800'
                : 'bg-slate-100 text-slate-800 border-slate-300'
            }`}
            aria-label="Basculer le thème"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          
          <button
            onClick={onOpenCvModal}
            className="p-2 text-xs font-medium text-white bg-blue-600 rounded-lg"
            aria-label="Télécharger le CV"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`p-2 rounded-lg focus:outline-none ${
              theme === 'dark' ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
            aria-label="Ouvrir le menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          className={`sm:hidden border-b px-4 pt-3 pb-5 space-y-3 ${
            theme === 'dark'
              ? 'bg-[#0d101a] border-slate-800 text-slate-200'
              : 'bg-white border-slate-200 text-slate-800 shadow-xl'
          }`}
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-base font-semibold hover:text-blue-500 border-b border-slate-800/20"
            >
              {link.label}
            </a>
          ))}
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCvModal();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-semibold text-white bg-blue-600 rounded-xl"
            >
              <Download className="w-4 h-4" />
              Télécharger CV (PDF Officiel)
            </button>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-semibold rounded-xl border ${
                theme === 'dark'
                  ? 'bg-slate-900 text-slate-200 border-slate-700'
                  : 'bg-slate-100 text-slate-800 border-slate-300'
              }`}
            >
              Formulaire de contact
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
