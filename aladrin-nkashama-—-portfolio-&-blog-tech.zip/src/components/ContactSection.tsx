import React, { useState } from 'react';
import { PERSONAL_INFO } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { Mail, Phone, MapPin, Send, MessageSquare, CheckCircle, ShoppingBag, ExternalLink } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { theme } = useTheme();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    projectType: 'Recrutement / Poste CDI',
    message: ''
  });

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [successMessage, setSuccessMessage] = useState('');

  const projectTypes = [
    'Recrutement / Poste CDI',
    'Mission de Consultance / Projet',
    'Gestion & Structuration de Données',
    'Audit Cybersécurité & Réseau',
    'Cartographie & Dépouillement SIG',
    'Maintenance Matérielle & Décodage',
    'Autre demande'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      alert('Veuillez remplir tous les champs obligatoires (Nom, Email, Message).');
      return;
    }

    setStatus('submitting');

    setTimeout(() => {
      setStatus('success');
      setSuccessMessage(`Merci ${formData.name}. Votre message a bien été transmis à Aladrin Nkashama. Vous recevrez une réponse sous 24 heures.`);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        projectType: 'Recrutement / Poste CDI',
        message: ''
      });
    }, 800);
  };

  const getWhatsAppLink = () => {
    const text = encodeURIComponent(
      `Bonjour Aladrin Nkashama, je vous contacte depuis votre portfolio professionnel au sujet de : ${formData.subject || 'une opportunité technique'}.`
    );
    return `https://wa.me/243994116853?text=${text}`;
  };

  const getMailtoLink = () => {
    const subject = encodeURIComponent(`[Contact Portfolio] ${formData.subject || 'Opportunité'}`);
    const body = encodeURIComponent(
      `Nom: ${formData.name}\nEmail: ${formData.email}\nTéléphone: ${formData.phone}\nType de mission: ${formData.projectType}\n\nMessage:\n${formData.message}`
    );
    return `mailto:${PERSONAL_INFO.email}?subject=${subject}&body=${body}`;
  };

  return (
    <section
      id="contact"
      className={`py-20 border-t transition-colors ${
        theme === 'dark' ? 'bg-[#090b12] border-slate-800/80' : 'bg-white border-slate-200'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-wider text-blue-500 font-bold mb-2">
            Disponibilité & Échanges
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-display ${
              theme === 'dark' ? 'text-white' : 'text-slate-900'
            }`}
          >
            Formulaire de Contact Direct
          </h2>
          <p
            className={`text-base mt-3 leading-relaxed ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Vous avez un projet de structuration de données, un poste à pourvoir, un besoin en audit informatique ou une mission cartographique ? Contactez-moi directement.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Direct Coordinates Card (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div
              className={`rounded-3xl p-6 sm:p-7 space-y-6 border ${
                theme === 'dark'
                  ? 'bg-[#0d101a] border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              <h3 className={`text-lg font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                Coordonnées Directes
              </h3>

              {/* Email */}
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-blue-600/10 text-blue-500 flex items-center justify-center shrink-0 mt-0.5">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Courriel direct</div>
                  <a
                    href={`mailto:${PERSONAL_INFO.email}`}
                    className={`text-sm font-bold font-mono transition-colors ${
                      theme === 'dark' ? 'text-white hover:text-blue-400' : 'text-slate-900 hover:text-blue-600'
                    }`}
                  >
                    {PERSONAL_INFO.email}
                  </a>
                </div>
              </div>

              {/* Phones */}
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-600/10 text-emerald-500 flex items-center justify-center shrink-0 mt-0.5">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Téléphone & Ligne directe</div>
                  <div className="space-y-1 mt-0.5">
                    {PERSONAL_INFO.phones.map((phone, pIdx) => (
                      <div key={pIdx}>
                        <a
                          href={`tel:${phone.replace(/\s+/g, '')}`}
                          className={`text-sm font-bold font-mono transition-colors block ${
                            theme === 'dark' ? 'text-white hover:text-emerald-400' : 'text-slate-900 hover:text-emerald-600'
                          }`}
                        >
                          {phone}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* WhatsApp direct chat button */}
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0 mt-0.5">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">WhatsApp Professionnel</div>
                  <a
                    href={`https://wa.me/243994116853?text=${encodeURIComponent('Bonjour Aladrin Nkashama, je vous contacte depuis votre portfolio.')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-emerald-500 hover:underline font-bold inline-flex items-center gap-1 mt-0.5"
                  >
                    <span>Démarrer une conversation WhatsApp</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Location */}
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-600/10 text-amber-500 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Localisation principale</div>
                  <div className={`text-xs font-medium mt-0.5 leading-relaxed ${
                    theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    {PERSONAL_INFO.address}
                  </div>
                </div>
              </div>

              {/* Boutique & Chariow link */}
              <div className={`pt-4 border-t ${theme === 'dark' ? 'border-slate-800' : 'border-slate-200'}`}>
                <div className="text-xs text-slate-400 mb-2 font-medium">Boutique en ligne officielle :</div>
                <a
                  href={PERSONAL_INFO.shopUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center justify-between p-3 rounded-2xl border text-xs transition-colors ${
                    theme === 'dark'
                      ? 'bg-slate-900 border-slate-800 hover:border-blue-500 text-slate-200'
                      : 'bg-slate-50 border-slate-200 hover:border-blue-500 text-slate-800'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-amber-500" />
                    <span className="font-semibold">Boutique Chariow (Logiciels & Produits)</span>
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                </a>
              </div>
            </div>

            {/* Response commitment banner */}
            <div
              className={`p-4.5 rounded-2xl border text-xs leading-relaxed ${
                theme === 'dark'
                  ? 'bg-blue-950/20 border-blue-900/40 text-blue-300'
                  : 'bg-blue-50 border-blue-200 text-blue-900'
              }`}
            >
              <strong className="block mb-1 font-bold">Délai de réponse garanti :</strong>
              Aladrin consulte régulièrement ses notifications professionnelles et s'engage à vous répondre sous 24 heures pour toute proposition ou étude de projet.
            </div>

          </div>

          {/* Right Column: Interactive Contact Form (7 cols) */}
          <div className="lg:col-span-7">
            <div
              className={`rounded-3xl p-6 sm:p-8 border ${
                theme === 'dark'
                  ? 'bg-[#0d101a] border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              {status === 'success' ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-center mx-auto text-emerald-500">
                    <CheckCircle className="w-7 h-7" />
                  </div>
                  <h3 className={`text-xl font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                    Message Transmis avec Succès
                  </h3>
                  <p className={`text-sm max-w-md mx-auto leading-relaxed ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
                    {successMessage}
                  </p>
                  <div className="pt-4 flex flex-wrap justify-center gap-3">
                    <button
                      onClick={() => setStatus('idle')}
                      className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors cursor-pointer"
                    >
                      Envoyer un autre message
                    </button>
                    <a
                      href={getWhatsAppLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-5 py-2.5 text-xs font-bold text-emerald-500 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl transition-colors"
                    >
                      Discuter sur WhatsApp &rarr;
                    </a>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Name */}
                    <div>
                      <label className={`block text-xs font-semibold mb-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                        Nom complet <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: Jean Mukendi"
                        className={`w-full px-3.5 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors ${
                          theme === 'dark'
                            ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                            : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label className={`block text-xs font-semibold mb-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                        Adresse e-mail <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="nom@organisation.cd"
                        className={`w-full px-3.5 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors ${
                          theme === 'dark'
                            ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                            : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Phone */}
                    <div>
                      <label className={`block text-xs font-semibold mb-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                        Téléphone / WhatsApp
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+243 ..."
                        className={`w-full px-3.5 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors ${
                          theme === 'dark'
                            ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                            : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>

                    {/* Project Type */}
                    <div>
                      <label className={`block text-xs font-semibold mb-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                        Nature de la demande
                      </label>
                      <select
                        value={formData.projectType}
                        onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                        className={`w-full px-3.5 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors cursor-pointer ${
                          theme === 'dark'
                            ? 'bg-slate-900 border-slate-700 text-white'
                            : 'bg-slate-50 border-slate-300 text-slate-900'
                        }`}
                      >
                        {projectTypes.map((pt, i) => (
                          <option key={i} value={pt} className={theme === 'dark' ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}>
                            {pt}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Subject */}
                  <div>
                    <label className={`block text-xs font-semibold mb-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                      Objet du message
                    </label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      placeholder="Ex: Proposition de mission bases de données à Kinshasa"
                      className={`w-full px-3.5 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors ${
                        theme === 'dark'
                          ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                          : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>

                  {/* Message */}
                  <div>
                    <label className={`block text-xs font-semibold mb-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                      Détails de votre message ou projet <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Décrivez votre besoin, le contexte de votre structure ou les compétences recherchées..."
                      className={`w-full px-3.5 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors resize-y ${
                        theme === 'dark'
                          ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                          : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>

                  {/* Submit and alternative action buttons */}
                  <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                    <button
                      type="submit"
                      disabled={status === 'submitting'}
                      className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer hover:scale-[1.02]"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{status === 'submitting' ? 'Envoi en cours...' : 'Envoyer le message'}</span>
                    </button>

                    <a
                      href={getMailtoLink()}
                      className={`w-full sm:w-auto text-center px-4 py-3 text-xs font-semibold rounded-xl border transition-colors ${
                        theme === 'dark'
                          ? 'text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 border-slate-700'
                          : 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border-slate-300'
                      }`}
                    >
                      Ouvrir mon client e-mail
                    </a>
                  </div>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
