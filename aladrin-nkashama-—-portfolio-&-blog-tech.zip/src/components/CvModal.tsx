import React, { useState } from 'react';
import { PERSONAL_INFO, EXPERIENCES_DATA, EDUCATION_DATA, CERTIFICATIONS_DATA, LANGUAGES_DATA, REFERENCES_DATA } from '../data/cvData';
import { X, Download, Printer, Copy, Check, FileText, ExternalLink, Mail, Phone, MapPin } from 'lucide-react';

interface CvModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CvModal: React.FC<CvModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadText = () => {
    const cvText = `
============================================================
CURRICULUM VITAE — ALADRIN NKASHAMA
============================================================
Ingénieur informaticien, infographe, maintenanceur, Développeur junior,
Programmeur junior, Technicien électricien, chauffeur, mécanicien.

COAST & CONTACT :
Courriel : ${PERSONAL_INFO.email}
Téléphones : ${PERSONAL_INFO.phones.join(', ')}
Adresse : ${PERSONAL_INFO.address}
État civil : ${PERSONAL_INFO.birthInfo} | ${PERSONAL_INFO.nationality} | ${PERSONAL_INFO.maritalStatus}
Boutique : ${PERSONAL_INFO.shopUrl}
Chaînes YouTube : ${PERSONAL_INFO.youtubeChannels.map(y => y.url).join(' | ')}
Facebook : ${PERSONAL_INFO.facebookProfile}

PROFIL PROFESSIONNEL :
${PERSONAL_INFO.aboutText.join('\n\n')}

EXPÉRIENCE PROFESSIONNELLE :
${EXPERIENCES_DATA.map(exp => `
- ${exp.role} — ${exp.company} (${exp.location})
  Période : ${exp.period}
  Missions :
  ${exp.responsibilities.map(r => `  * ${r}`).join('\n')}
`).join('\n')}

FORMATIONS ACADÉMIQUES :
${EDUCATION_DATA.map(edu => `
- ${edu.degree} — ${edu.institution} (${edu.location})
  Période : ${edu.period}
  ${edu.description.map(d => `  * ${d}`).join('\n')}
`).join('\n')}

AUTRES FORMATIONS & CERTIFICATIONS :
${CERTIFICATIONS_DATA.map(cert => `
- ${cert.title} — ${cert.provider} (${cert.location})
  Période : ${cert.period}
  ${cert.highlights.map(h => `  * ${h}`).join('\n')}
`).join('\n')}

LANGUES :
${LANGUAGES_DATA.map(l => `- ${l.name} : ${l.level}`).join('\n')}

PERSONNES DE RÉFÉRENCES :
${REFERENCES_DATA.map(ref => `- ${ref.name}, ${ref.title} (${ref.organization}) — Tél : ${ref.phone || 'Sur demande'}`).join('\n')}

ATTESTATION :
« Je jure sur mon honneur que les renseignements fournis ci-hauts sont sincères, exacts et vérifiables. »
Kinshasa, République Démocratique du Congo.
============================================================
    `.trim();

    const blob = new Blob([cvText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'CV_Aladrin_Nkashama_Officiel.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="bg-[#0e111a] border border-slate-700 rounded-2xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Control Bar (Non printable) */}
        <div className="no-print p-4 bg-[#141824] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            <span className="text-sm font-bold text-white">
              Curriculum Vitae Officiel — Aladrin Nkashama
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors cursor-pointer"
              title="Générer un PDF propre via l'impression du navigateur"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimer / PDF</span>
            </button>

            <button
              onClick={handleDownloadText}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
              title="Télécharger la version texte du CV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Fichier Texte</span>
            </button>

            <button
              onClick={handleCopy}
              className="p-2 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Copier le lien du portfolio"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable CV Container */}
        <div className="overflow-y-auto p-4 sm:p-8 bg-white text-slate-900 print:p-0 print:m-0 selection:bg-red-500 selection:text-white">
          
          {/* Header Banner - replicating the iconic red header block from the original CV */}
          <div className="bg-[#b31414] text-white p-5 sm:p-7 rounded-t-xl print:rounded-none relative flex flex-col sm:flex-row items-center gap-6">
            
            {/* Monogram Emblem (No Photo) */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-white text-[#b31414] flex items-center justify-center font-extrabold font-mono text-2xl sm:text-3xl shrink-0 shadow-md">
              AN
            </div>

            {/* Info in Banner */}
            <div className="flex-1 text-center sm:text-left space-y-1.5">
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-wide uppercase font-display">
                ALADRIN NKASHAMA
              </h1>
              
              <div className="text-xs sm:text-sm text-red-100 font-medium">
                Ingénieur informaticien, infographe, maintenanceur, Développeur junior, Programmeur junior, Technicien électricien, chauffeur, mécanicien.
              </div>

              <div className="pt-1 text-xs text-white/95 space-y-0.5">
                <div className="font-semibold">{PERSONAL_INFO.email}</div>
                <div>{PERSONAL_INFO.phones.join(' / ')}</div>
                <div>{PERSONAL_INFO.address}</div>
                <div>Né à Tshikapa, le 23 août 1997 · Homme · Congolaise · Célibataire</div>
              </div>
            </div>
          </div>

          {/* Social & Channel Links Sub-bar */}
          <div className="bg-slate-900 text-slate-200 text-[11px] p-2.5 px-4 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
            <div>
              <span className="text-amber-400 font-semibold">Boutique : </span>
              <a href={PERSONAL_INFO.shopUrl} target="_blank" rel="noreferrer" className="text-slate-300 hover:underline">
                app.chariow.com/stores/store_4ovdbam8bkhz
              </a>
            </div>
            <div>
              <span className="text-red-400 font-semibold">YouTube : </span>
              <a href={PERSONAL_INFO.youtubeChannels[0].url} target="_blank" rel="noreferrer" className="text-slate-300 hover:underline">
                @aladarttech
              </a>
              <span className="mx-1">/</span>
              <a href={PERSONAL_INFO.youtubeChannels[1].url} target="_blank" rel="noreferrer" className="text-slate-300 hover:underline">
                @AladArttechsolutions
              </a>
            </div>
          </div>

          {/* CV Body Columns */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-6">
            
            {/* Left Column: Skills, Languages, Interests (4 cols) */}
            <div className="md:col-span-4 space-y-6 border-r-0 md:border-r border-slate-200 pr-0 md:pr-6">
              
              {/* Compétences Clés */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  COMPÉTENCES
                </div>
                <ul className="text-xs space-y-1.5 text-slate-800 font-medium">
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Informatique & Systèmes</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Bases de Données (SQL / Saisie)</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Développement Web (HTML/JS)</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Cybersécurité & Hacking éthique</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Cartographie & SIG (RGPH-2)</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Décodage & Maintenance Mobile</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Prise de vue & Montage Vidéo</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Électricité générale des bâtiments</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Logistique & Gestion de stocks</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-[#b31414]" />
                    <span>Conduite & Mécanique auto</span>
                  </li>
                </ul>
              </div>

              {/* Langues */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  LANGUES
                </div>
                <div className="text-xs space-y-2 text-slate-800">
                  {LANGUAGES_DATA.map((l, i) => (
                    <div key={i}>
                      <div className="flex justify-between font-semibold">
                        <span>{l.name}</span>
                        <span className="text-slate-600 text-[11px]">{l.level.split('/')[0]}</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1 rounded-full mt-1">
                        <div className="bg-[#b31414] h-1 rounded-full" style={{ width: `${l.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Capacités & Atouts */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  CAPACITÉS
                </div>
                <ul className="text-xs space-y-1 text-slate-700">
                  <li>▪ Courageux</li>
                  <li>▪ Flexible</li>
                  <li>▪ Curieux</li>
                  <li>▪ Adaptif</li>
                  <li>▪ Convaincant</li>
                </ul>
              </div>

              {/* Centres d'intérêt */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  CENTRES D'INTÉRÊT
                </div>
                <ul className="text-xs space-y-1 text-slate-700">
                  <li>▪ Lecteur & Veille</li>
                  <li>▪ Informatique & BD</li>
                  <li>▪ Photographie</li>
                  <li>▪ Électricité générale</li>
                  <li>▪ Voyage</li>
                </ul>
              </div>

            </div>

            {/* Right Column: Profile, Experience, Formation (8 cols) */}
            <div className="md:col-span-8 space-y-6">
              
              {/* Profil Professionnel */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  PROFIL
                </div>
                <div className="text-xs sm:text-[13px] text-slate-800 leading-relaxed space-y-2 text-justify">
                  {PERSONAL_INFO.aboutText.map((p, idx) => (
                    <p key={idx}>{p}</p>
                  ))}
                </div>
              </div>

              {/* Expérience Professionnelle */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  EXPÉRIENCE PROFESSIONNELLE
                </div>
                <div className="space-y-4 text-xs">
                  {EXPERIENCES_DATA.map((exp) => (
                    <div key={exp.id} className="border-b border-slate-100 pb-3">
                      <div className="flex justify-between items-start font-bold text-slate-900 text-[13px]">
                        <span>{exp.role}</span>
                        <span className="text-[#b31414] font-mono text-xs">{exp.period}</span>
                      </div>
                      <div className="text-slate-600 font-medium italic mb-1.5">
                        {exp.company} — {exp.location}
                      </div>
                      <ul className="space-y-1 text-slate-700 pl-3">
                        {exp.responsibilities.slice(0, 3).map((r, rIdx) => (
                          <li key={rIdx} className="list-disc leading-relaxed">
                            {r}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Formations Académiques */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  FORMATION
                </div>
                <div className="space-y-3 text-xs">
                  {EDUCATION_DATA.map((edu) => (
                    <div key={edu.id} className="border-b border-slate-100 pb-2">
                      <div className="flex justify-between font-bold text-slate-900">
                        <span>{edu.degree}</span>
                        <span className="text-blue-700 font-mono text-xs">{edu.period}</span>
                      </div>
                      <div className="text-slate-600 italic mb-1">{edu.institution}</div>
                      <ul className="text-slate-700 space-y-0.5 pl-3">
                        {edu.description.map((d, dIdx) => (
                          <li key={dIdx} className="list-disc leading-tight">{d}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Autres Formations Certifiantes */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  AUTRES FORMATIONS & CERTIFICATIONS
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {CERTIFICATIONS_DATA.map((cert) => (
                    <div key={cert.id} className="p-2.5 rounded bg-slate-50 border border-slate-200">
                      <div className="font-bold text-slate-900">{cert.title}</div>
                      <div className="text-slate-600 text-[11px]">{cert.provider} ({cert.period})</div>
                      <div className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                        {cert.highlights[0]}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Personnes de référence */}
              <div>
                <div className="bg-[#b31414] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 mb-3">
                  PERSONNES DE RÉFÉRENCES ET CONTACTS
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {REFERENCES_DATA.map((ref, idx) => (
                    <div key={idx} className="p-2 bg-slate-50 rounded border border-slate-200">
                      <div className="font-bold text-slate-900">{ref.name}</div>
                      <div className="text-slate-600 text-[11px]">{ref.title} — {ref.organization}</div>
                      {ref.phone && (
                        <div className="text-blue-700 font-mono font-medium text-[11px] mt-0.5">
                          Tél : {ref.phone}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Serment sur l'honneur */}
              <div className="pt-4 border-t-2 border-slate-900 text-center space-y-1">
                <p className="text-xs font-serif italic text-slate-800">
                  « Je jure sur mon honneur que les renseignements fournis ci-hauts sont sincères, exacts et vérifiables. »
                </p>
                <p className="text-xs font-mono font-bold text-slate-900">
                  Kinshasa, le 27 Septembre 2026
                </p>
              </div>

            </div>

          </div>

        </div>

        {/* Modal Bottom Footer (no-print) */}
        <div className="no-print p-4 bg-[#141824] border-t border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Document officiel conforme au dossier de candidature d'Aladrin Nkashama.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700"
          >
            Fermer l'aperçu
          </button>
        </div>

      </div>
    </div>
  );
};
