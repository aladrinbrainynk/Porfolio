import React from 'react';
import { LANGUAGES_DATA, REFERENCES_DATA } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { Languages, UserCheck, Phone, CheckCircle, ShieldCheck, Heart, Compass } from 'lucide-react';

export const LanguagesAndReferences: React.FC = () => {
  const { theme } = useTheme();

  const interests = [
    'Lecture & Veille technologique',
    'Gestion de bases de données',
    'Photographie & Prise de vue',
    'Saisie et archivage documentaire',
    'Électricité & Schémas techniques',
    'Voyages et découvertes'
  ];

  const qualities = [
    'Courageux & Résilient',
    'Flexible face aux contraintes',
    'Curieux de nouvelles technologies',
    'Adaptabilité rapide aux environnements',
    'Convaincant & Sens de l\'écoute'
  ];

  return (
    <section
      id="references"
      className={`py-20 border-t transition-colors ${
        theme === 'dark' ? 'bg-[#07090e] border-slate-800/80' : 'bg-slate-50 border-slate-200'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-wider text-blue-500 font-bold mb-2">
            Polyvalence & Vérifiabilité
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-display ${
              theme === 'dark' ? 'text-white' : 'text-slate-900'
            }`}
          >
            Langues, Références & Valeurs
          </h2>
          <p
            className={`text-base mt-3 leading-relaxed ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Une communication fluide en milieu professionnel et des références reconnues au sein des institutions publiques, éducatives et humanitaires.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Languages & Soft Skills (6 cols) */}
          <div className="lg:col-span-6 space-y-8">
            
            {/* Languages Block */}
            <div
              className={`rounded-3xl p-6 sm:p-7 border ${
                theme === 'dark'
                  ? 'bg-[#0d101a] border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              <div className="flex items-center gap-2.5 text-base font-bold mb-6">
                <Languages className="w-5 h-5 text-blue-500" />
                <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                  Langues Pratiquées ({LANGUAGES_DATA.length})
                </span>
              </div>

              <div className="space-y-4">
                {LANGUAGES_DATA.map((lang, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className={`font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                        {lang.name}
                      </span>
                      <span className="text-slate-500 font-mono font-medium">{lang.level}</span>
                    </div>
                    
                    <div
                      className={`w-full h-1.5 rounded-full overflow-hidden ${
                        theme === 'dark' ? 'bg-slate-800' : 'bg-slate-100'
                      }`}
                    >
                      <div
                        className="h-full bg-blue-600 rounded-full"
                        style={{ width: `${lang.pct}%` }}
                      />
                    </div>
                    
                    <div className="text-[11px] text-slate-500 italic">
                      {lang.note}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Qualities & Personal Assets */}
            <div
              className={`rounded-3xl p-6 sm:p-7 border ${
                theme === 'dark'
                  ? 'bg-[#0d101a] border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              <div className="flex items-center gap-2.5 text-base font-bold mb-4">
                <Heart className="w-5 h-5 text-rose-500" />
                <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                  Capacités & Atouts Personnels
                </span>
              </div>
              <div className="flex flex-wrap gap-2 mb-6">
                {qualities.map((q, i) => (
                  <span
                    key={i}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border ${
                      theme === 'dark'
                        ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                        : 'bg-slate-100 border-slate-200 text-slate-800'
                    }`}
                  >
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{q}</span>
                  </span>
                ))}
              </div>

              <div
                className={`flex items-center gap-2.5 text-base font-bold mb-3 pt-4 border-t ${
                  theme === 'dark' ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <Compass className="w-5 h-5 text-indigo-500" />
                <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                  Centres d'Intérêt
                </span>
              </div>
              <div className="flex flex-wrap gap-2 text-xs">
                {interests.map((interest, idx) => (
                  <span
                    key={idx}
                    className={`px-3 py-1 rounded-lg border font-medium ${
                      theme === 'dark'
                        ? 'bg-slate-900 border-slate-800 text-slate-300'
                        : 'bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: References & Attestation (6 cols) */}
          <div className="lg:col-span-6 space-y-8">
            
            {/* References Block */}
            <div
              className={`rounded-3xl p-6 sm:p-7 border ${
                theme === 'dark'
                  ? 'bg-[#0d101a] border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              <div className="flex items-center gap-2.5 text-base font-bold mb-6">
                <UserCheck className="w-5 h-5 text-emerald-500" />
                <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                  Personnes de Référence Vérifiables
                </span>
              </div>

              <div className="space-y-3.5">
                {REFERENCES_DATA.map((ref, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl border transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      theme === 'dark'
                        ? 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className={`text-sm font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                        {ref.name}
                      </div>
                      <div className="text-xs text-blue-500 font-semibold">{ref.title}</div>
                      <div className="text-xs text-slate-500">{ref.organization}</div>
                    </div>

                    {ref.phone ? (
                      <a
                        href={`tel:${ref.phone.replace(/\s+/g, '')}`}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold text-emerald-500 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl transition-colors whitespace-nowrap self-start sm:self-center"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>{ref.phone}</span>
                      </a>
                    ) : (
                      <span className="text-[11px] text-slate-400 italic">Contact direct sur demande</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Official Honor Pledge from CV */}
            <div
              className={`rounded-3xl p-6 sm:p-7 text-center space-y-3 border ${
                theme === 'dark'
                  ? 'bg-gradient-to-br from-blue-950/30 to-slate-900 border-blue-900/40'
                  : 'bg-gradient-to-br from-blue-50 to-slate-50 border-blue-200'
              }`}
            >
              <div className="w-11 h-11 rounded-2xl bg-blue-600/10 text-blue-500 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-500">
                Engagement sur l'Honneur
              </h3>
              <p
                className={`text-xs sm:text-sm italic max-w-md mx-auto leading-relaxed ${
                  theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                « Je jure sur mon honneur que les renseignements fournis ci-hauts sont sincères, exacts et vérifiables. »
              </p>
              <div className="text-xs text-slate-400 font-mono font-bold pt-1">
                Kinshasa, République Démocratique du Congo
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
