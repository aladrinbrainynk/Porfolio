import React, { useState, useMemo } from 'react';
import { SKILLS_DATA, SKILL_CATEGORIES, SkillItem } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { Search, CheckCircle, Database, Shield, Globe, Map, Video, Cpu, Truck, Sparkles, X, ChevronRight } from 'lucide-react';
import securityLabImg from '../assets/images/security_systems_lab_1790519315502.jpg';

export const InteractiveSkills: React.FC = () => {
  const { theme } = useTheme();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSkill, setSelectedSkill] = useState<SkillItem | null>(null);

  const skillCounts = useMemo(() => {
    const counts: Record<string, number> = { all: SKILLS_DATA.length };
    SKILLS_DATA.forEach((s) => {
      counts[s.category] = (counts[s.category] || 0) + 1;
    });
    return counts;
  }, []);

  const filteredSkills = useMemo(() => {
    return SKILLS_DATA.filter((skill) => {
      const matchesCategory = activeCategory === 'all' || skill.category === activeCategory;
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        skill.name.toLowerCase().includes(query) ||
        skill.summary.toLowerCase().includes(query) ||
        skill.tools.some((t) => t.toLowerCase().includes(query)) ||
        skill.practicalApplication.toLowerCase().includes(query);
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'database':
        return <Database className="w-4 h-4 text-blue-500" />;
      case 'security':
        return <Shield className="w-4 h-4 text-emerald-500" />;
      case 'web':
        return <Globe className="w-4 h-4 text-indigo-500" />;
      case 'gis':
        return <Map className="w-4 h-4 text-amber-500" />;
      case 'media':
        return <Video className="w-4 h-4 text-purple-500" />;
      case 'hardware':
        return <Cpu className="w-4 h-4 text-cyan-500" />;
      case 'logistics':
        return <Truck className="w-4 h-4 text-rose-500" />;
      default:
        return <Sparkles className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <section
      id="competences"
      className={`py-20 border-t relative transition-colors ${
        theme === 'dark' ? 'bg-[#090b12] border-slate-800/80' : 'bg-white border-slate-200'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-wider text-blue-500 font-bold mb-2">
            Expertise & Technologies
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-display ${
              theme === 'dark' ? 'text-white' : 'text-slate-900'
            }`}
          >
            Compétences Clés & Savoir-Faire
          </h2>
          <p
            className={`text-base mt-3 leading-relaxed ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            De l'administration de bases de données relationnelles volumineuses au hacking éthique, en passant par le découpage cartographique SIG et la maintenance électronique mobile.
          </p>
        </div>

        {/* Interactive Controls Bar */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-8">
          
          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 scrollbar-none py-1 max-w-full">
            {SKILL_CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              const count = skillCounts[cat.id] || 0;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all duration-150 whitespace-nowrap cursor-pointer shrink-0 border ${
                    isActive
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/30 scale-[1.02]'
                      : theme === 'dark'
                      ? 'bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-800'
                      : 'bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200 border-slate-200'
                  }`}
                >
                  <span className={isActive ? 'text-white' : ''}>
                    {getCategoryIcon(cat.id)}
                  </span>
                  <span>{cat.label}</span>
                  <span
                    className={`font-mono text-[11px] px-1.5 py-0.2 rounded-full ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : theme === 'dark'
                        ? 'bg-slate-800 text-slate-400'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick Search Input */}
          <div className="relative min-w-[260px] shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtrer (ex: SQL, SIG, Nmap, GPS)..."
              className={`w-full pl-10 pr-8 py-2.5 text-xs rounded-xl border focus:outline-none focus:border-blue-500 transition-colors ${
                theme === 'dark'
                  ? 'bg-slate-900 border-slate-700/80 text-white placeholder-slate-500'
                  : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
              }`}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Skills Grid */}
        {filteredSkills.length === 0 ? (
          <div
            className={`p-12 text-center rounded-2xl border ${
              theme === 'dark'
                ? 'bg-slate-900/40 border-slate-800 text-slate-400'
                : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            <p className="text-sm">Aucune compétence ne correspond à votre recherche "{searchQuery}".</p>
            <button
              onClick={() => {
                setActiveCategory('all');
                setSearchQuery('');
              }}
              className="mt-3 text-xs text-blue-500 hover:underline font-semibold"
            >
              Réinitialiser les filtres
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSkills.map((skill) => (
              <div
                key={skill.id}
                onClick={() => setSelectedSkill(skill)}
                className={`group relative rounded-2xl p-5.5 transition-all duration-200 hover:-translate-y-1 cursor-pointer flex flex-col justify-between border shadow-sm ${
                  theme === 'dark'
                    ? 'bg-[#0f121d] border-slate-800 hover:border-blue-500/60 hover:shadow-xl hover:shadow-blue-950/20'
                    : 'bg-white border-slate-200 hover:border-blue-500 hover:shadow-lg'
                }`}
              >
                <div>
                  {/* Top Row: Category & Level */}
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-400">
                      {getCategoryIcon(skill.category)}
                      <span className="capitalize font-medium">{skill.category}</span>
                    </div>
                    <span className="font-mono text-xs font-bold text-blue-500 tabular-nums">
                      {skill.level}% · {skill.levelLabel}
                    </span>
                  </div>

                  {/* Title */}
                  <h3
                    className={`text-base font-bold group-hover:text-blue-500 transition-colors ${
                      theme === 'dark' ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {skill.name}
                  </h3>

                  {/* Progress Bar */}
                  <div
                    className={`w-full h-1.5 rounded-full mt-3 overflow-hidden ${
                      theme === 'dark' ? 'bg-slate-800' : 'bg-slate-100'
                    }`}
                  >
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-indigo-500 rounded-full transition-all duration-500"
                      style={{ width: `${skill.level}%` }}
                    />
                  </div>

                  {/* Summary */}
                  <p
                    className={`text-xs mt-3.5 line-clamp-2 leading-relaxed ${
                      theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                    }`}
                  >
                    {skill.summary}
                  </p>

                  {/* Tool chips */}
                  <div className="flex flex-wrap gap-1.5 mt-3.5">
                    {skill.tools.slice(0, 4).map((tool, idx) => (
                      <span
                        key={idx}
                        className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                          theme === 'dark'
                            ? 'text-slate-300 bg-slate-800/80 border-slate-700/60'
                            : 'text-slate-700 bg-slate-100 border-slate-200'
                        }`}
                      >
                        {tool}
                      </span>
                    ))}
                    {skill.tools.length > 4 && (
                      <span className="text-[11px] text-slate-400 px-1 py-0.5">
                        +{skill.tools.length - 4}
                      </span>
                    )}
                  </div>
                </div>

                {/* Practical footnote */}
                <div
                  className={`pt-4 mt-4 border-t text-[11px] flex items-center justify-between ${
                    theme === 'dark' ? 'border-slate-800/80 text-slate-400' : 'border-slate-100 text-slate-500'
                  }`}
                >
                  <span className="truncate pr-2">Déployé en contexte réel</span>
                  <span className="text-blue-500 group-hover:translate-x-0.5 transition-transform shrink-0 font-bold flex items-center gap-1">
                    Détails &rarr;
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Technical Lab & Systems Callout Card */}
        <div
          className={`mt-14 rounded-3xl p-6 sm:p-8 overflow-hidden border ${
            theme === 'dark'
              ? 'bg-gradient-to-r from-[#0d101a] to-[#121626] border-slate-800'
              : 'bg-gradient-to-r from-slate-50 to-blue-50/50 border-slate-200 shadow-sm'
          }`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-bold text-blue-500 uppercase tracking-wider">
                Méthodologie & Rigueur Éprouvée
              </div>
              <h3
                className={`text-2xl font-bold font-display ${
                  theme === 'dark' ? 'text-white' : 'text-slate-900'
                }`}
              >
                Sécurisation, Structuration de Données et Audit Systèmes
              </h3>
              <p
                className={`text-sm leading-relaxed ${
                  theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                Fort de ma double formation en <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>Informatique de Gestion (ISC)</strong> et en <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>Hacking Éthique (Cyberbox)</strong>, j'interviens pour auditer les postes, restructurer les flux de documents et concevoir des bases pérennes éliminant la redondance et le risque de perte.
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <div
                  className={`flex items-center gap-2 text-xs font-medium ${
                    theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>Modélisation 3FN & Intégrité relationnelle</span>
                </div>
                <div
                  className={`flex items-center gap-2 text-xs font-medium ${
                    theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>Audits de vulnérabilités & Cryptographie</span>
                </div>
                <div
                  className={`flex items-center gap-2 text-xs font-medium ${
                    theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>SIG & Données géocodées pour recensements</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden border border-slate-700/50 shadow-xl aspect-video">
                <img
                  src={securityLabImg}
                  alt="Laboratoire de cybersécurité et audit matériel"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 text-[11px] text-white bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 font-medium">
                  Environnement d'audit et tests de sécurité
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Interactive Skill Detail Modal */}
      {selectedSkill && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setSelectedSkill(null)}
        >
          <div
            className={`border rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl relative ${
              theme === 'dark'
                ? 'bg-[#0f121d] border-slate-700 text-slate-100'
                : 'bg-white border-slate-300 text-slate-900'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedSkill(null)}
              className={`absolute top-4 right-4 p-2 rounded-xl transition-colors ${
                theme === 'dark'
                  ? 'text-slate-400 hover:text-white hover:bg-slate-800'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs text-blue-500 mb-2 font-mono font-semibold">
              {getCategoryIcon(selectedSkill.category)}
              <span className="capitalize">{selectedSkill.category}</span>
              <span>·</span>
              <span>Niveau {selectedSkill.level}% ({selectedSkill.levelLabel})</span>
            </div>

            <h3 className="text-xl font-bold mb-2 font-display">
              {selectedSkill.name}
            </h3>

            <p
              className={`text-sm leading-relaxed mb-4 ${
                theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              {selectedSkill.summary}
            </p>

            <div
              className={`space-y-4 pt-3 border-t text-xs ${
                theme === 'dark' ? 'border-slate-800' : 'border-slate-200'
              }`}
            >
              <div>
                <span className="text-slate-400 block mb-1.5 font-bold">Outils & Technologies associés :</span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedSkill.tools.map((t, i) => (
                    <span
                      key={i}
                      className={`px-2.5 py-1 rounded-lg border font-mono ${
                        theme === 'dark'
                          ? 'bg-slate-800 border-slate-700 text-slate-200'
                          : 'bg-slate-100 border-slate-200 text-slate-800'
                      }`}
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-bold">Application pratique & Expérience réelle :</span>
                <div
                  className={`p-3.5 rounded-xl border leading-relaxed ${
                    theme === 'dark'
                      ? 'bg-blue-950/20 border-blue-900/40 text-blue-200'
                      : 'bg-blue-50 border-blue-200 text-blue-900'
                  }`}
                >
                  {selectedSkill.practicalApplication}
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedSkill(null)}
                className={`px-4 py-2 text-xs font-bold rounded-xl cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-slate-800 hover:bg-slate-700 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
