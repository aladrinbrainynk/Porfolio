import React, { useState } from 'react';
import { EXPERIENCES_DATA, EDUCATION_DATA, CERTIFICATIONS_DATA } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { Briefcase, GraduationCap, Award, Calendar, MapPin, ChevronRight, CheckCircle2 } from 'lucide-react';

export const TimelineSection: React.FC = () => {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState<'experiences' | 'education' | 'certifications'>('experiences');

  return (
    <section
      id="parcours"
      className={`py-20 border-t transition-colors ${
        theme === 'dark' ? 'bg-[#07090e] border-slate-800/80' : 'bg-slate-50 border-slate-200'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-wider text-blue-500 font-bold mb-2">
            Carrière & Qualifications
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-display ${
              theme === 'dark' ? 'text-white' : 'text-slate-900'
            }`}
          >
            Parcours Professionnel & Formations
          </h2>
          <p
            className={`text-base mt-3 leading-relaxed ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Un cheminement constant guidé par l'apprentissage continu, la rigueur opérationnelle et le service rendu aux administrations et entreprises.
          </p>
        </div>

        {/* Modern Interactive Tab Cards Switcher */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mb-10">
          
          {/* Tab 1: Expériences */}
          <button
            onClick={() => setActiveTab('experiences')}
            className={`group text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 cursor-pointer relative overflow-hidden flex flex-col justify-between border ${
              activeTab === 'experiences'
                ? theme === 'dark'
                  ? 'bg-gradient-to-b from-blue-950/60 to-[#0e1220] border-blue-500 shadow-xl shadow-blue-950/40 -translate-y-0.5'
                  : 'bg-white border-blue-600 shadow-lg -translate-y-0.5'
                : theme === 'dark'
                ? 'bg-[#0d0f17] hover:bg-slate-900/90 border-slate-800 hover:border-slate-700'
                : 'bg-white/80 hover:bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                  activeTab === 'experiences'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : theme === 'dark'
                    ? 'bg-slate-800 text-slate-400 group-hover:text-white'
                    : 'bg-slate-100 text-slate-600 group-hover:text-slate-900'
                }`}
              >
                <Briefcase className="w-5 h-5" />
              </div>

              <span
                className={`text-xs font-mono font-semibold px-2.5 py-1 rounded-full ${
                  activeTab === 'experiences'
                    ? 'bg-blue-500/20 text-blue-500 border border-blue-500/40'
                    : theme === 'dark'
                    ? 'bg-slate-800/80 text-slate-400'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {EXPERIENCES_DATA.length} Postes
              </span>
            </div>

            <div>
              <div
                className={`text-sm sm:text-base font-bold transition-colors ${
                  activeTab === 'experiences'
                    ? theme === 'dark' ? 'text-white' : 'text-blue-950'
                    : theme === 'dark' ? 'text-slate-300 group-hover:text-white' : 'text-slate-700 group-hover:text-slate-900'
                }`}
              >
                Expériences Professionnelles
              </div>
              <div className="text-xs text-slate-400 mt-1">
                ONG ADPS, RGPH-2, Mairie, Shop Christian...
              </div>
            </div>

            {/* Active bottom accent bar */}
            <div
              className={`h-1 w-full rounded-full mt-3.5 transition-all ${
                activeTab === 'experiences'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-500'
                  : 'bg-transparent'
              }`}
            />
          </button>

          {/* Tab 2: Formations */}
          <button
            onClick={() => setActiveTab('education')}
            className={`group text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 cursor-pointer relative overflow-hidden flex flex-col justify-between border ${
              activeTab === 'education'
                ? theme === 'dark'
                  ? 'bg-gradient-to-b from-blue-950/60 to-[#0e1220] border-blue-500 shadow-xl shadow-blue-950/40 -translate-y-0.5'
                  : 'bg-white border-blue-600 shadow-lg -translate-y-0.5'
                : theme === 'dark'
                ? 'bg-[#0d0f17] hover:bg-slate-900/90 border-slate-800 hover:border-slate-700'
                : 'bg-white/80 hover:bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                  activeTab === 'education'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : theme === 'dark'
                    ? 'bg-slate-800 text-slate-400 group-hover:text-white'
                    : 'bg-slate-100 text-slate-600 group-hover:text-slate-900'
                }`}
              >
                <GraduationCap className="w-5 h-5" />
              </div>

              <span
                className={`text-xs font-mono font-semibold px-2.5 py-1 rounded-full ${
                  activeTab === 'education'
                    ? 'bg-blue-500/20 text-blue-500 border border-blue-500/40'
                    : theme === 'dark'
                    ? 'bg-slate-800/80 text-slate-400'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {EDUCATION_DATA.length} Diplômes
              </span>
            </div>

            <div>
              <div
                className={`text-sm sm:text-base font-bold transition-colors ${
                  activeTab === 'education'
                    ? theme === 'dark' ? 'text-white' : 'text-blue-950'
                    : theme === 'dark' ? 'text-slate-300 group-hover:text-white' : 'text-slate-700 group-hover:text-slate-900'
                }`}
              >
                Formations Diplômantes
              </div>
              <div className="text-xs text-slate-400 mt-1">
                ISC G3 Informatique, C.S. La Gloire...
              </div>
            </div>

            <div
              className={`h-1 w-full rounded-full mt-3.5 transition-all ${
                activeTab === 'education'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-500'
                  : 'bg-transparent'
              }`}
            />
          </button>

          {/* Tab 3: Certifications */}
          <button
            onClick={() => setActiveTab('certifications')}
            className={`group text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 cursor-pointer relative overflow-hidden flex flex-col justify-between border ${
              activeTab === 'certifications'
                ? theme === 'dark'
                  ? 'bg-gradient-to-b from-blue-950/60 to-[#0e1220] border-blue-500 shadow-xl shadow-blue-950/40 -translate-y-0.5'
                  : 'bg-white border-blue-600 shadow-lg -translate-y-0.5'
                : theme === 'dark'
                ? 'bg-[#0d0f17] hover:bg-slate-900/90 border-slate-800 hover:border-slate-700'
                : 'bg-white/80 hover:bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                  activeTab === 'certifications'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : theme === 'dark'
                    ? 'bg-slate-800 text-slate-400 group-hover:text-white'
                    : 'bg-slate-100 text-slate-600 group-hover:text-slate-900'
                }`}
              >
                <Award className="w-5 h-5" />
              </div>

              <span
                className={`text-xs font-mono font-semibold px-2.5 py-1 rounded-full ${
                  activeTab === 'certifications'
                    ? 'bg-blue-500/20 text-blue-500 border border-blue-500/40'
                    : theme === 'dark'
                    ? 'bg-slate-800/80 text-slate-400'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {CERTIFICATIONS_DATA.length} Spécialisations
              </span>
            </div>

            <div>
              <div
                className={`text-sm sm:text-base font-bold transition-colors ${
                  activeTab === 'certifications'
                    ? theme === 'dark' ? 'text-white' : 'text-blue-950'
                    : theme === 'dark' ? 'text-slate-300 group-hover:text-white' : 'text-slate-700 group-hover:text-slate-900'
                }`}
              >
                Certifications & Stages
              </div>
              <div className="text-xs text-slate-400 mt-1">
                Hacking éthique, Décodage mobile, Vidéo...
              </div>
            </div>

            <div
              className={`h-1 w-full rounded-full mt-3.5 transition-all ${
                activeTab === 'certifications'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-500'
                  : 'bg-transparent'
              }`}
            />
          </button>

        </div>

        {/* TAB 1: EXPERIENCES */}
        {activeTab === 'experiences' && (
          <div className="space-y-6">
            {EXPERIENCES_DATA.map((exp) => (
              <div
                key={exp.id}
                className={`rounded-2xl p-6 sm:p-7 transition-all duration-150 border ${
                  theme === 'dark'
                    ? 'bg-[#0d101a] border-slate-800 hover:border-slate-700'
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                }`}
              >
                <div
                  className={`flex flex-col md:flex-row md:items-start justify-between gap-4 pb-4 border-b ${
                    theme === 'dark' ? 'border-slate-800/80' : 'border-slate-100'
                  }`}
                >
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <h3
                        className={`text-lg sm:text-xl font-bold ${
                          theme === 'dark' ? 'text-white' : 'text-slate-900'
                        }`}
                      >
                        {exp.role}
                      </h3>
                      {exp.current && (
                        <span className="text-[11px] font-bold text-emerald-500 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                          En poste actuellement
                        </span>
                      )}
                      <span
                        className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                          theme === 'dark' ? 'text-slate-400 bg-slate-800' : 'text-slate-600 bg-slate-100'
                        }`}
                      >
                        {exp.type}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs">
                      <span className="font-bold text-blue-500">{exp.company}</span>
                      <span className="text-slate-400">·</span>
                      <span className="flex items-center gap-1 text-slate-500">
                        <MapPin className="w-3 h-3" />
                        {exp.location}
                      </span>
                    </div>
                  </div>

                  <div
                    className={`flex items-center gap-1.5 text-xs font-mono px-3 py-1.5 rounded-xl border self-start ${
                      theme === 'dark'
                        ? 'text-slate-300 bg-slate-900 border-slate-800'
                        : 'text-slate-700 bg-slate-50 border-slate-200'
                    }`}
                  >
                    <Calendar className="w-3.5 h-3.5 text-blue-500" />
                    <span>{exp.period}</span>
                  </div>
                </div>

                {/* Responsibilities */}
                <div className="mt-4">
                  <div
                    className={`text-xs font-bold uppercase tracking-wider mb-3 ${
                      theme === 'dark' ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    Missions & Réalisations Clés :
                  </div>
                  <ul className="space-y-2">
                    {exp.responsibilities.map((resp, rIdx) => (
                      <li
                        key={rIdx}
                        className={`text-xs sm:text-sm flex items-start gap-2.5 leading-relaxed ${
                          theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
                        }`}
                      >
                        <ChevronRight className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                        <span>{resp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Skills used */}
                <div
                  className={`mt-5 pt-4 border-t flex flex-wrap items-center gap-2 ${
                    theme === 'dark' ? 'border-slate-800/60' : 'border-slate-100'
                  }`}
                >
                  <span className="text-[11px] text-slate-500 font-medium">Compétences mobilisées :</span>
                  {exp.skillsApplied.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                        theme === 'dark'
                          ? 'text-slate-300 bg-slate-800/80 border-slate-700/60'
                          : 'text-slate-700 bg-slate-100 border-slate-200'
                      }`}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 2: EDUCATION */}
        {activeTab === 'education' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {EDUCATION_DATA.map((edu) => (
              <div
                key={edu.id}
                className={`rounded-2xl p-6 flex flex-col justify-between border ${
                  theme === 'dark'
                    ? 'bg-[#0d101a] border-slate-800'
                    : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="text-blue-500 font-bold">{edu.badge}</span>
                    <span className="font-mono text-slate-500">{edu.period}</span>
                  </div>

                  <h3
                    className={`text-base sm:text-lg font-bold mb-1 ${
                      theme === 'dark' ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {edu.degree}
                  </h3>
                  <div className="text-xs font-semibold text-slate-500 mb-4">
                    {edu.institution} · {edu.location}
                  </div>

                  <ul
                    className={`space-y-2 border-t pt-3 ${
                      theme === 'dark' ? 'border-slate-800' : 'border-slate-100'
                    }`}
                  >
                    {edu.description.map((desc, dIdx) => (
                      <li
                        key={dIdx}
                        className={`text-xs flex items-start gap-2 leading-relaxed ${
                          theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
                        <span>{desc}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div
                  className={`mt-6 pt-3 border-t text-[11px] font-mono text-slate-500 ${
                    theme === 'dark' ? 'border-slate-800' : 'border-slate-100'
                  }`}
                >
                  Diplôme officiel certifié
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 3: CERTIFICATIONS */}
        {activeTab === 'certifications' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CERTIFICATIONS_DATA.map((cert) => (
              <div
                key={cert.id}
                className={`rounded-2xl p-5.5 flex flex-col justify-between border ${
                  theme === 'dark'
                    ? 'bg-[#0d101a] border-slate-800'
                    : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-blue-500 font-mono font-bold">{cert.category}</span>
                    <span className="text-slate-500 font-mono text-[11px]">{cert.period}</span>
                  </div>

                  <h3
                    className={`text-base font-bold mb-1.5 ${
                      theme === 'dark' ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {cert.title}
                  </h3>

                  <div className="text-xs text-slate-500 font-semibold mb-3">
                    {cert.provider} · {cert.location}
                  </div>

                  <ul
                    className={`space-y-1.5 border-t pt-3 ${
                      theme === 'dark' ? 'border-slate-800/80' : 'border-slate-100'
                    }`}
                  >
                    {cert.highlights.map((h, hIdx) => (
                      <li
                        key={hIdx}
                        className={`text-xs flex items-start gap-2 leading-relaxed ${
                          theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      >
                        <span className="text-blue-500 mt-0.5 font-bold">·</span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div
                  className={`mt-4 pt-3 border-t text-[11px] font-mono text-slate-500 ${
                    theme === 'dark' ? 'border-slate-800' : 'border-slate-100'
                  }`}
                >
                  Attestation & Acquis validés
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
