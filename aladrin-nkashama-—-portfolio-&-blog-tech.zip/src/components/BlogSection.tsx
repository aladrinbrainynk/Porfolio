import React, { useState, useMemo } from 'react';
import { BLOG_POSTS, BlogPost, PERSONAL_INFO } from '../data/cvData';
import { useTheme } from '../context/ThemeContext';
import { BookOpen, Clock, Calendar, Search, ArrowRight, X, Share2, Check, Sparkles, Bookmark } from 'lucide-react';
import workspaceImg from '../assets/images/showcase_tech_workspace_1790519303050.jpg';

export const BlogSection: React.FC = () => {
  const { theme } = useTheme();
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('Tous');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const categories = ['Tous', 'Bases de Données & SIG', 'Cybersécurité', 'Hardware & Électronique', 'Logistique & Gestion'];

  const postCounts = useMemo(() => {
    const counts: Record<string, number> = { Tous: BLOG_POSTS.length };
    BLOG_POSTS.forEach((p) => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    return counts;
  }, []);

  const filteredPosts = useMemo(() => {
    return BLOG_POSTS.filter((post) => {
      const matchCat = selectedCategory === 'Tous' || post.category === selectedCategory;
      const query = searchQuery.toLowerCase().trim();
      const matchQuery =
        !query ||
        post.title.toLowerCase().includes(query) ||
        post.summary.toLowerCase().includes(query) ||
        post.tags.some((t) => t.toLowerCase().includes(query));
      return matchCat && matchQuery;
    });
  }, [selectedCategory, searchQuery]);

  const handleShare = (post: BlogPost) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${window.location.origin}/#blog-${post.slug}`);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const featuredPost = BLOG_POSTS[0];

  return (
    <section
      id="blog"
      className={`py-20 border-t relative transition-colors ${
        theme === 'dark' ? 'bg-[#090b12] border-slate-800/80' : 'bg-white border-slate-200'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-wider text-blue-500 font-bold mb-2">
            Blog Technique & Réflexions
          </div>
          <h2
            className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-display ${
              theme === 'dark' ? 'text-white' : 'text-slate-900'
            }`}
          >
            Analyses Pratiques & Retours d'Expérience
          </h2>
          <p
            className={`text-base mt-3 leading-relaxed ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Des articles techniques fondés sur les réalités de terrain en RDC : optimisation des registres municipaux, détection des vulnérabilités, logistique informatisée et découpage cartographique.
          </p>
        </div>

        {/* Featured Article Card */}
        {selectedCategory === 'Tous' && !searchQuery && (
          <div
            className={`mb-14 rounded-3xl overflow-hidden border transition-all duration-200 ${
              theme === 'dark'
                ? 'bg-gradient-to-br from-[#0d101a] to-[#141829] border-slate-800 hover:border-blue-500/50'
                : 'bg-white border-slate-200 hover:border-blue-500 shadow-md'
            }`}
          >
            <div className="grid grid-cols-1 lg:grid-cols-12">
              <div className="lg:col-span-6 relative aspect-video lg:aspect-auto min-h-[280px] bg-slate-900">
                <img
                  src={workspaceImg}
                  alt="Espace de travail et administration de données"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-black/85 via-black/30 to-transparent" />
                <div className="absolute top-4 left-4 text-xs font-bold text-blue-400 bg-black/80 backdrop-blur-md px-3 py-1 rounded-lg border border-blue-500/30">
                  Article à la Une
                </div>
              </div>

              <div className="lg:col-span-6 p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
                    <span className="text-blue-500 font-bold">{featuredPost.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{featuredPost.date}</span>
                    <span aria-hidden="true">·</span>
                    <span>{featuredPost.readTime} de lecture</span>
                  </div>

                  <h3
                    className={`text-xl sm:text-2xl font-bold mb-3 transition-colors ${
                      theme === 'dark' ? 'text-white hover:text-blue-400' : 'text-slate-900 hover:text-blue-600'
                    }`}
                  >
                    {featuredPost.title}
                  </h3>

                  <p
                    className={`text-sm leading-relaxed mb-4 ${
                      theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                    }`}
                  >
                    {featuredPost.summary}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {featuredPost.tags.map((t, i) => (
                      <span
                        key={i}
                        className={`text-xs font-mono px-2 py-0.5 rounded ${
                          theme === 'dark'
                            ? 'text-slate-400 bg-slate-800'
                            : 'text-slate-600 bg-slate-100'
                        }`}
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <div
                  className={`pt-4 border-t flex items-center justify-between ${
                    theme === 'dark' ? 'border-slate-800/80' : 'border-slate-100'
                  }`}
                >
                  <div className="text-xs text-slate-400">
                    Par <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>{PERSONAL_INFO.name}</strong>
                  </div>
                  <button
                    onClick={() => setSelectedPost(featuredPost)}
                    className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors cursor-pointer"
                  >
                    <span>Lire l'analyse complète</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filter Bar with Elevated Category Tabs */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none py-1">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              const count = postCounts[cat] || 0;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl whitespace-nowrap transition-all duration-150 cursor-pointer shrink-0 border ${
                    isActive
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/30 scale-[1.02]'
                      : theme === 'dark'
                      ? 'bg-[#0d101a] text-slate-300 hover:text-white hover:bg-slate-800 border-slate-800'
                      : 'bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200 border-slate-200'
                  }`}
                >
                  <span>{cat}</span>
                  <span
                    className={`font-mono text-[11px] px-1.5 py-0.2 rounded-full ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : theme === 'dark'
                        ? 'bg-slate-800 text-slate-400'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher un article..."
              className={`w-full pl-10 pr-4 py-2 text-xs rounded-xl border focus:outline-none focus:border-blue-500 ${
                theme === 'dark'
                  ? 'bg-slate-900 border-slate-700/80 text-white placeholder-slate-500'
                  : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
              }`}
            />
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              onClick={() => setSelectedPost(post)}
              className={`group rounded-2xl p-5.5 flex flex-col justify-between transition-all duration-150 hover:-translate-y-0.5 cursor-pointer border shadow-sm ${
                theme === 'dark'
                  ? 'bg-[#0d101a] border-slate-800 hover:border-blue-500/50'
                  : 'bg-white border-slate-200 hover:border-blue-500'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-2.5">
                  <span className="text-blue-500 font-bold">{post.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{post.readTime}</span>
                </div>

                <h3
                  className={`text-base font-bold group-hover:text-blue-500 transition-colors line-clamp-2 mb-2 leading-snug ${
                    theme === 'dark' ? 'text-white' : 'text-slate-900'
                  }`}
                >
                  {post.title}
                </h3>

                <p
                  className={`text-xs line-clamp-3 leading-relaxed mb-4 ${
                    theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                  }`}
                >
                  {post.summary}
                </p>

                <div className="flex flex-wrap gap-1.5 mb-4">
                  {post.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                        theme === 'dark'
                          ? 'text-slate-400 bg-slate-800/80'
                          : 'text-slate-600 bg-slate-100'
                      }`}
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              <div
                className={`pt-3 border-t flex items-center justify-between text-xs ${
                  theme === 'dark' ? 'border-slate-800/80 text-slate-400' : 'border-slate-100 text-slate-500'
                }`}
              >
                <span className="text-[11px]">{post.date}</span>
                <span className="text-blue-500 font-bold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                  Lire &rarr;
                </span>
              </div>
            </article>
          ))}
        </div>

      </div>

      {/* Full Article Reader Modal */}
      {selectedPost && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
          onClick={() => setSelectedPost(null)}
        >
          <div
            className={`border rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl relative my-8 ${
              theme === 'dark'
                ? 'bg-[#0f121e] border-slate-700 text-slate-100'
                : 'bg-white border-slate-300 text-slate-900'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedPost(null)}
              className={`absolute top-4 right-4 p-2 rounded-xl transition-colors ${
                theme === 'dark'
                  ? 'text-slate-400 hover:text-white hover:bg-slate-800'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs text-blue-500 font-bold mb-3">
              <span>{selectedPost.category}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-400 font-normal">{selectedPost.date}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-400 font-normal">{selectedPost.readTime} de lecture</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold mb-4 font-display leading-tight">
              {selectedPost.title}
            </h2>

            {/* Author byline */}
            <div
              className={`flex items-center gap-3 py-3 border-y mb-6 text-xs ${
                theme === 'dark' ? 'border-slate-800 text-slate-300' : 'border-slate-200 text-slate-700'
              }`}
            >
              <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold font-mono">
                AN
              </div>
              <div>
                <div className="font-bold">{PERSONAL_INFO.name}</div>
                <div className="text-slate-400">{PERSONAL_INFO.title}</div>
              </div>
            </div>

            {/* Key takeaways callout box */}
            <div
              className={`mb-6 p-4.5 rounded-2xl border ${
                theme === 'dark'
                  ? 'bg-blue-950/30 border-blue-800/40'
                  : 'bg-blue-50/80 border-blue-200'
              }`}
            >
              <div className="flex items-center gap-2 text-xs font-bold text-blue-500 mb-2">
                <Sparkles className="w-4 h-4" />
                <span>Points Clés à Retenir :</span>
              </div>
              <ul className="space-y-1.5">
                {selectedPost.keyTakeaways.map((takeaway, idx) => (
                  <li
                    key={idx}
                    className={`text-xs flex items-start gap-2 ${
                      theme === 'dark' ? 'text-slate-200' : 'text-slate-800'
                    }`}
                  >
                    <span className="text-blue-500 font-bold">✓</span>
                    <span>{takeaway}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Article Content */}
            <div
              className={`space-y-4 text-sm sm:text-base leading-relaxed ${
                theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
              }`}
            >
              {selectedPost.content.map((paragraph, pIdx) => (
                <p key={pIdx} className="leading-relaxed">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Tags */}
            <div
              className={`mt-8 pt-4 border-t flex flex-wrap items-center gap-2 ${
                theme === 'dark' ? 'border-slate-800' : 'border-slate-200'
              }`}
            >
              <span className="text-xs text-slate-400">Thématiques :</span>
              {selectedPost.tags.map((tag, tIdx) => (
                <span
                  key={tIdx}
                  className={`text-xs font-mono px-2.5 py-1 rounded ${
                    theme === 'dark' ? 'text-slate-300 bg-slate-800' : 'text-slate-700 bg-slate-100'
                  }`}
                >
                  #{tag}
                </span>
              ))}
            </div>

            {/* Bottom Actions */}
            <div
              className={`mt-6 pt-4 border-t flex flex-wrap items-center justify-between gap-3 ${
                theme === 'dark' ? 'border-slate-800' : 'border-slate-200'
              }`}
            >
              <button
                onClick={() => handleShare(selectedPost)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer border ${
                  theme === 'dark'
                    ? 'text-slate-300 bg-slate-800 hover:bg-slate-700 border-slate-700'
                    : 'text-slate-700 bg-slate-100 hover:bg-slate-200 border-slate-200'
                }`}
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-500" /> : <Share2 className="w-4 h-4" />}
                <span>{copiedLink ? 'Lien copié dans le presse-papier !' : 'Partager cet article'}</span>
              </button>

              <div className="flex items-center gap-2">
                <a
                  href="#contact"
                  onClick={() => setSelectedPost(null)}
                  className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors"
                >
                  Échanger sur ce sujet
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
