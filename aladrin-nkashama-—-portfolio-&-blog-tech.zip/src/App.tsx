/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { InteractiveSkills } from './components/InteractiveSkills';
import { TimelineSection } from './components/TimelineSection';
import { BlogSection } from './components/BlogSection';
import { LanguagesAndReferences } from './components/LanguagesAndReferences';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CvModal } from './components/CvModal';
import { Download } from 'lucide-react';

function AppContent() {
  const [isCvModalOpen, setIsCvModalOpen] = useState(false);
  const { theme } = useTheme();

  return (
    <div
      className={`min-h-screen flex flex-col font-sans selection:bg-blue-600 selection:text-white transition-colors duration-200 ${
        theme === 'dark' ? 'bg-[#090b12] text-slate-100' : 'bg-[#f8fafc] text-slate-900'
      }`}
    >
      {/* Top Navbar adhering to the 3-zone contract */}
      <Navbar onOpenCvModal={() => setIsCvModalOpen(true)} />

      {/* Main Content Sections */}
      <main className="flex-grow">
        {/* Hero Section */}
        <Hero onOpenCvModal={() => setIsCvModalOpen(true)} />

        {/* Interactive Skills Matrix with real-time search & modal inspection */}
        <InteractiveSkills />

        {/* Career, Academic Education & Certifications Timeline */}
        <TimelineSection />

        {/* Professional Blog & Engineering Case Studies */}
        <BlogSection />

        {/* Languages, Verified References & Honor Pledge */}
        <LanguagesAndReferences />

        {/* Contact Form & Direct Channels */}
        <ContactSection />
      </main>

      {/* Clean Footer */}
      <Footer onOpenCvModal={() => setIsCvModalOpen(true)} />

      {/* Floating Action Button for direct CV access */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col items-end gap-2.5 no-print">
        <button
          onClick={() => setIsCvModalOpen(true)}
          className="group flex items-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-2xl shadow-xl shadow-blue-600/30 transition-all duration-200 hover:scale-105 cursor-pointer"
          aria-label="Télécharger le CV officiel"
        >
          <Download className="w-4 h-4 animate-bounce" />
          <span className="hidden sm:inline">Télécharger CV Officiel</span>
          <span className="sm:hidden font-mono">CV</span>
        </button>
      </div>

      {/* Modal for official CV replica with print, PDF and direct text download */}
      <CvModal isOpen={isCvModalOpen} onClose={() => setIsCvModalOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
