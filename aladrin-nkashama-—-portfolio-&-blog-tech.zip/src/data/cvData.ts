export interface SkillItem {
  id: string;
  name: string;
  category: 'database' | 'web' | 'security' | 'gis' | 'media' | 'hardware' | 'logistics';
  level: number; // 0 to 100
  levelLabel: string;
  summary: string;
  tools: string[];
  practicalApplication: string;
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  startDate: string;
  endDate: string;
  current?: boolean;
  type: 'CDI' | 'Mission' | 'Contrat' | 'Stage';
  responsibilities: string[];
  skillsApplied: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  location: string;
  period: string;
  description: string[];
  badge: string;
}

export interface CertificationItem {
  id: string;
  title: string;
  provider: string;
  location: string;
  period: string;
  category: string;
  highlights: string[];
}

export interface ReferenceItem {
  name: string;
  title: string;
  organization: string;
  phone?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  category: string;
  date: string;
  readTime: string;
  summary: string;
  content: string[];
  keyTakeaways: string[];
  tags: string[];
}

export const PERSONAL_INFO = {
  name: 'Aladrin Nkashama',
  title: 'Ingénieur Informaticien & Expert Bases de Données',
  subtitle: 'Gestionnaire de données · Cybersécurité · Développeur Web · Infographe · Cartographe SIG',
  email: 'Aladrinnkashama9@gmail.com',
  phones: ['+243 994 116 853', '+243 993 901 630'],
  whatsapp: '+243994116853',
  address: 'C/ NGALIMA, Q/KIMPE AV/KISANTU N°13 BIS, Kinshasa, RD Congo',
  birthInfo: 'Né à Tshikapa, le 23 août 1997',
  nationality: 'Congolaise',
  maritalStatus: 'Célibataire',
  shopUrl: 'https://app.chariow.com/stores/store_4ovdbam8bkhz/products?status=all',
  shopName: 'Boutique Officielle Chariow',
  youtubeChannels: [
    { name: 'AladArttech', url: 'https://www.youtube.com/@aladarttech', desc: 'Tutoriels informatiques, créativité et technologie' },
    { name: 'AladArttech Solutions', url: 'https://www.youtube.com/@AladArttechsolutions', desc: 'Solutions techniques d\'entreprise et innovations' }
  ],
  facebookProfile: 'https://www.facebook.com/aladrin.nkashama',
  facebookPage: 'https://www.facebook.com/share/1Dx6D2jj91/',
  aboutText: [
    "Professionnel de l'informatique doté d'une expertise solide en gestion de bases de données et en organisation documentaire, je suis reconnu pour ma rigueur et ma capacité à optimiser les processus administratifs dans divers environnements.",
    "Avec une formation en électricité générale complétée par une expérience pratique en milieu éducatif et administratif, je possède une approche polyvalente qui me permet de gérer efficacement les flux d'information et les architectures matérielles.",
    "Soucieux d'apporter des solutions innovantes, je combine mes compétences techniques en informatique avec une forte capacité d'adaptation pour répondre aux besoins spécifiques des organisations privées comme des institutions publiques."
  ],
  stats: [
    { label: "Années d'expérience", value: "7+" },
    { label: "Formations certifiantes", value: "10" },
    { label: "Bases de données administrées", value: "15+" },
    { label: "Langues parlées", value: "6" }
  ]
};

export const SKILL_CATEGORIES = [
  { id: 'all', label: 'Toutes les compétences' },
  { id: 'database', label: 'Bases de Données & Systèmes' },
  { id: 'security', label: 'Cybersécurité & Hacking Éthique' },
  { id: 'web', label: 'Développement Web & Code' },
  { id: 'gis', label: 'Cartographie & SIG' },
  { id: 'media', label: 'Infographie & Audiovisuel' },
  { id: 'hardware', label: 'Hardware & Électrotechnique' },
  { id: 'logistics', label: 'Logistique & Traçabilité' }
] as const;

export const SKILLS_DATA: SkillItem[] = [
  {
    id: 'db-management',
    name: 'Gestion de Bases de Données Relationnelles',
    category: 'database',
    level: 95,
    levelLabel: 'Expert',
    summary: 'Conception, administration, requêtes SQL, normalisation et optimisation des flux de données en milieu administratif et logistique.',
    tools: ['SQL', 'Access', 'MySQL', 'Modélisation Relationnelle', 'Excel Avancé / Tableaux croisés'],
    practicalApplication: 'Déployé avec succès à la Mairie de Tshikapa, au C.S. Shamuana et à l’ONG ADPS pour structurer des milliers de dossiers.'
  },
  {
    id: 'archiving-docs',
    name: 'Archivage Électronique & Organisation Documentaire',
    category: 'database',
    level: 92,
    levelLabel: 'Avancé',
    summary: 'Numérisation, classement systématique, indexation et sécurisation des documents administratifs et comptables.',
    tools: ['GED', 'Systèmes de classement', 'Automatisation bureautique', 'Contrôle d\'intégrité'],
    practicalApplication: 'Réduction de 70% du temps de recherche documentaire dans les registres communaux et les registres scolaires.'
  },
  {
    id: 'cybersecurity',
    name: 'Hacking Éthique & Tests d\'Intrusion',
    category: 'security',
    level: 86,
    levelLabel: 'Certifié',
    summary: 'Identification des failles système, protocoles de cryptographie, analyse réseau et durcissement des postes de travail.',
    tools: ['Nmap', 'Wireshark', 'Cryptographie', 'Audit de vulnérabilités', 'Sécurité réseau'],
    practicalApplication: 'Formation spécialisée Cyberbox Kinshasa ; audits préventifs des accès et sécurisation des postes d\'administration.'
  },
  {
    id: 'web-dev',
    name: 'Développement Web Frontend & Applicatif',
    category: 'web',
    level: 85,
    levelLabel: 'Opérationnel',
    summary: 'Création de sites internet dynamiques, conception d\'interfaces utilisateur claires et structurées, intégration de bases de données.',
    tools: ['HTML5', 'CSS3', 'JavaScript', 'Architecture Web', 'Responsive UI'],
    practicalApplication: 'Formé au Centre Joseph ADA ; réalisation de portails d\'information et de vitrines produits en ligne.'
  },
  {
    id: 'cartography',
    name: 'Cartographie Numérique & Données Géoréférencées',
    category: 'gis',
    level: 90,
    levelLabel: 'Certifié RGPH',
    summary: 'Listing des sites habités, localisation d\'infrastructures territoriales, constitution de répertoires géoréférencés et dossiers cartographiques.',
    tools: ['SIG', 'Sondage aréolaire', 'GPS / Géolocalisation', 'Bases spatiales', 'Outils RGPH-2'],
    practicalApplication: 'Opérateur Cartographe officiel pour le recensement général RGPH-2, délimitation des aires de dénombrement.'
  },
  {
    id: 'mobile-hardware',
    name: 'Décodage & Maintenance Matérielle Mobile',
    category: 'hardware',
    level: 94,
    levelLabel: 'Expert',
    summary: 'Diagnostic au composant de cartes mères, flash de firmwares, déblocage réseau et réparation électronique de smartphones.',
    tools: ['Box de déblocage', 'Analyse schémas CM', 'Outils de diagnostic', 'Firmware Flashers', 'Microsoudure'],
    practicalApplication: 'Formé par ALC&LGS Bénin ; gestion technique quotidienne au Shop Christian sur plus de 1 200 terminaux.'
  },
  {
    id: 'audiovisual',
    name: 'Prise de Vue & Montage Vidéo',
    category: 'media',
    level: 88,
    levelLabel: 'Confirmé',
    summary: 'Techniques de cadrage, gestion de la lumière en intérieur/extérieur, montage vidéo rythmé et habillage sonore.',
    tools: ['Équipement caméra pro', 'Logiciels de montage vidéo', 'Sound design', 'Colorimétrie', 'Workflow post-production'],
    practicalApplication: 'Formation Herim Business Kinshasa ; production de contenus pédagogiques pour les chaînes AladArttech.'
  },
  {
    id: 'electrical',
    name: 'Électrotechnique & Câblage de Bâtiments',
    category: 'hardware',
    level: 90,
    levelLabel: 'Diplômé d\'État',
    summary: 'Lecture et interprétation de plans et schémas électriques, installation, maintenance préventive et dépannage sécurisé.',
    tools: ['Schémas unifilaires', 'Tableaux de distribution', 'Multimètre', 'Normes NFC / CEI', 'Protection disjoncteurs'],
    practicalApplication: 'Diplôme d\'État en Électricité Générale (C.S. La Gloire) et formation pratique Centre Notre Avenir Kikwit.'
  },
  {
    id: 'logistics',
    name: 'Logistique & Gestion des Stocks Informatiques',
    category: 'logistics',
    level: 91,
    levelLabel: 'Spécialiste',
    summary: 'Suivi des stocks, traçabilité des flux d\'équipements, traitement informatique des approvisionnements et support aux équipes.',
    tools: ['Gestion de stocks', 'Inventaire informatisé', 'Feuilles de calcul complexes', 'Chaîne logistique ADPS'],
    practicalApplication: 'Poste actuel de Logisticien Informaticien au sein de l\'ONG ADPS (Kinshasa/Tshikapa).'
  },
  {
    id: 'mechanics',
    name: 'Conduite Automobile & Maintenance Mécanique',
    category: 'hardware',
    level: 86,
    levelLabel: 'Qualifié CAMS',
    summary: 'Maintenance préventive des moteurs thermiques, contrôle des fluides, sécurité routière et conduite professionnelle.',
    tools: ['Diagnostic moteur thermique', 'Réglages courants', 'Sécurité routière', 'Assistant maître de conduite'],
    practicalApplication: 'Formé et certifié CAMS Kikwit ; expérience d\'assistant maître de conduite et chauffeur opérationnel.'
  }
];

export const EXPERIENCES_DATA: ExperienceItem[] = [
  {
    id: 'adps-logistics',
    role: 'Logisticien Informaticien',
    company: 'ONG ADPS',
    location: 'Kinshasa / Tshikapa, RDC',
    period: 'Juin 2024 — À ce jour',
    startDate: 'Juin 2024',
    endDate: 'Présent',
    current: true,
    type: 'CDI',
    responsibilities: [
      'Gestion et maintenance des bases de données logistiques et informatiques pour assurer la haute disponibilité de l\'information.',
      'Optimisation des flux de données administratives et rationalisation des processus internes de l\'organisation.',
      'Classification, numérisation et archivage électronique systématique des documents administratifs garantissant une traçabilité totale.',
      'Développement et mise à jour de systèmes informatiques dédiés à la gestion et au réapprovisionnement logistique.',
      'Saisie et traitement analytique des données de distribution et des stocks dans les logiciels métiers.',
      'Assistance technique directe aux équipes de terrain pour assurer la continuité opérationnelle des outils informatiques.'
    ],
    skillsApplied: ['Bases de données SQL', 'Gestion de stocks', 'Archivage GED', 'Support réseau & postes']
  },
  {
    id: 'rgph-carto',
    role: 'Opérateur Cartographe',
    company: 'RGPH-2 (Recensement Général de la Population et de l\'Habitat)',
    location: 'RDC',
    period: '09/09/2026 — 15/09/2026',
    startDate: 'Sept. 2026',
    endDate: 'Sept. 2026',
    type: 'Mission',
    responsibilities: [
      'Établissement exhaustif de la liste de tous les sites, avenues et localités habités sur la zone assignée.',
      'Localisation et enregistrement précis des infrastructures existantes dans les bases territoriales nationales.',
      'Constitution du dossier cartographique délimitant sans ambiguïté les aires de dénombrement des Agents Recenseurs.',
      'Création des bases de sondage d\'unités aréolaires pour les besoins d\'enquêtes post-censitaires.',
      'Alimentation et vérification d\'intégrité de la base de données géo-référencées du projet national.'
    ],
    skillsApplied: ['SIG & Cartographie', 'GPS / Géolocalisation', 'Sondage aréolaire', 'Bases de données spatiales']
  },
  {
    id: 'shop-christian',
    role: 'Vendeur, Gérant et Informaticien',
    company: 'Shop Christian, Tpa',
    location: 'Tshikapa, RDC',
    period: '2022 — 2024',
    startDate: '2022',
    endDate: '2024',
    type: 'CDI',
    responsibilities: [
      'Gestion commerciale et technique : vente et tests poussés d\'appareils mobiles, ordinateurs et accessoires.',
      'Pilotage de l\'inventaire et réassortiment coordonné sur 3 boutiques partenaires.',
      'Prise en charge du service après-vente technique : réparation matérielle, flash de firmwares, déblocage réseau et réinitialisation sécurisée.',
      'Résolution des pannes logicielles et sécurisation des comptes utilisateurs.'
    ],
    skillsApplied: ['Décodage mobile', 'Gestion commerciale', 'Comptabilité de caisse', 'Micromécanique électronique']
  },
  {
    id: 'cams-driver',
    role: 'Chauffeur et Assistant du Maître de conduite',
    company: 'CAMS / GsmKikwit',
    location: 'Kikwit, RDC',
    period: '2021 — 2022',
    startDate: '2021',
    endDate: '2022',
    type: 'Contrat',
    responsibilities: [
      'Assurance de la sécurité et du bon état de marche de la flotte de véhicules.',
      'Diagnostic mécanique immédiat et maintenance préventive en cas de panne sur moteur thermique.',
      'Assistance pédagogique lors des séances pratiques de formation à la conduite automobile.'
    ],
    skillsApplied: ['Mécanique automobile', 'Sécurité routière', 'Conduite défensive', 'Maintenance préventive']
  },
  {
    id: 'shamuana-school',
    role: 'Informaticien & Chargé des Pratiques',
    company: 'C.S. Shamuana',
    location: 'Tshikapa, RDC',
    period: '2019 — 2021',
    startDate: '2019',
    endDate: '2021',
    type: 'CDI',
    responsibilities: [
      'Conception et gestion de la base de données scolaire (inscriptions, bulletins, scolarité des élèves).',
      'Saisie et mise en page de l\'ensemble des épreuves, correspondances officielles et rapports pédagogiques.',
      'Encadrement technique des travaux pratiques d\'informatique pour les élèves et le corps professoral.'
    ],
    skillsApplied: ['Bases de données scolaires', 'Suite Office avancée', 'Formation informatique', 'Maintenance informatique']
  },
  {
    id: 'mairie-tshikapa',
    role: 'Informaticien & Opérateur de Saisie',
    company: 'Mairie de Tshikapa',
    location: 'Tshikapa, RDC',
    period: 'Janvier 2017 — Mai 2019',
    startDate: 'Janv. 2017',
    endDate: 'Mai 2019',
    type: 'CDI',
    responsibilities: [
      'Gestion et mise à jour quotidienne des bases de données de l\'administration municipale.',
      'Saisie rapide et normalisée des actes d\'état civil, autorisations et correspondances du cabinet.',
      'Classement systématique et archivage physique et numérique des dossiers administratifs.',
      'Support technique bureautique auprès des différents départements de l\'hôtel de ville.'
    ],
    skillsApplied: ['Administration communale', 'Saisie rapide & intégrité', 'Archivage documentaire', 'Support bureautique']
  }
];

export const EDUCATION_DATA: EducationItem[] = [
  {
    id: 'isc-g3',
    degree: 'Graduat en Informatique de Gestion (G3)',
    institution: 'ISC / TPA (Institut Supérieur de Commerce)',
    location: 'Tshikapa, RDC',
    period: '2019 — 2022',
    badge: 'Enseignement Supérieur',
    description: [
      'Compréhension approfondie des systèmes d\'information et de leur rôle stratégique dans la gouvernance des organisations.',
      'Maîtrise de la modélisation, de la conception et de l\'optimisation de bases de données relationnelles complexes.',
      'Programmation orientée gestion de données et développement d\'applications métiers adaptées aux réalités des entreprises.'
    ]
  },
  {
    id: 'etat-electricite',
    degree: 'Diplôme d\'État en Électricité Générale',
    institution: 'C.S. La Gloire',
    location: 'Tshikapa, RDC',
    period: '2015 — 2016',
    badge: 'Diplôme d\'État',
    description: [
      'Maîtrise des principes fondamentaux de l\'électricité générale : lois de tension, intensité et circuits électriques.',
      'Capacité à lire, interpréter et concevoir des schémas d\'installations électriques domestiques et industrielles.',
      'Sécurité des personnes et conformité des tableaux de distribution.'
    ]
  },
  {
    id: 'certificat-primaire',
    degree: 'Certificat d\'Étude Primaire (CEP)',
    institution: 'Pépinière de Naboth',
    location: 'Tshikapa, RDC',
    period: '2009 — 2010',
    badge: 'Fondation Académique',
    description: [
      'Solide cursus d\'éducation fondamentale en sciences, calcul et communication écrite.'
    ]
  }
];

export const CERTIFICATIONS_DATA: CertificationItem[] = [
  {
    id: 'cert-cyber',
    title: 'Formation en Hacking Éthique & Cybersécurité',
    provider: 'Cyberbox',
    location: 'Kinshasa, RDC',
    period: 'Mars 2023 — Sept. 2023',
    category: 'Sécurité Réseau',
    highlights: [
      'Principes fondamentaux du hacking éthique et tests d\'intrusion pour détecter les failles.',
      'Application des méthodes de cryptographie pour sécuriser les données et communications.',
      'Analyse approfondie des protocoles réseau et conformité aux cadres éthiques et légaux.'
    ]
  },
  {
    id: 'cert-video',
    title: 'Formation en Prise de Vue & Montage Vidéo',
    provider: 'Herim Business',
    location: 'Kinshasa, RDC',
    period: 'Nov. 2023 — Mai 2023',
    category: 'Audiovisuel',
    highlights: [
      'Cadrage, composition, équilibrage d\'éclairage intérieur et extérieur.',
      'Montage vidéo multi-pistes, insertion d\'effets sonores et étalonnage visuel.',
      'Gestion complète de la chaîne de production audiovisuelle.'
    ]
  },
  {
    id: 'cert-decodage',
    title: 'Formation en Décodage des Appareils Cellulaires',
    provider: 'ALC & LGS / Unlock (Entreprise)',
    location: 'Bénin (Formation spécialisée)',
    period: 'Févr. 2020 — Févr. 2021',
    category: 'Hardware Mobile',
    highlights: [
      'Démontage/remontage minutieux, micro-inspection des cartes mères.',
      'Analyse des algorithmes de verrouillage réseau et bypass sécurisé de comptes utilisateurs.',
      'Flashage de firmwares d\'origine et restauration du système d\'exploitation.'
    ]
  },
  {
    id: 'cert-carto',
    title: 'Formation des Opérateurs Cartographes',
    provider: 'RGPH-2',
    location: 'RDC',
    period: 'Septembre 2026',
    category: 'Systèmes Géographiques',
    highlights: [
      'Localisation d\'infrastructures territoriales et découpage d\'aires censitaires.',
      'Alimentation de référentiels géocodés et méthodologie de sondage aréolaire.'
    ]
  },
  {
    id: 'cert-elec',
    title: 'Formation en Électrification des Bâtiments',
    provider: 'Centre Notre Avenir',
    location: 'Kikwit, RDC',
    period: 'Août 2019 — Déc. 2019',
    category: 'Électricité',
    highlights: [
      'Lecture de plans d\'architecte, schémas de câblage pour bâtiments à étages.',
      'Installation et maintenance de circuits d\'éclairage et de puissance.'
    ]
  },
  {
    id: 'cert-web',
    title: 'Formation en Création de Sites Internet',
    provider: 'Centre Joseph ADA',
    location: 'Kikwit, RDC',
    period: 'Mars 2019 — Juin 2019',
    category: 'Développement Web',
    highlights: [
      'Fondamentaux HTML, CSS, JavaScript et intégration avec les bases de données relationnelles.',
      'Conception de sites adaptés aux besoins d\'organisations locales.'
    ]
  },
  {
    id: 'cert-meca',
    title: 'Formation de Conduite et Mécanique Automobile',
    provider: 'CAMS / GsmKikwit',
    location: 'Kikwit, RDC',
    period: 'Juin 2018 — Janv. 2019',
    category: 'Automobile',
    highlights: [
      'Maintenance préventive des moteurs thermiques, contrôle des fluides.',
      'Code de la route et obligations légales des conducteurs professionnels.'
    ]
  },
  {
    id: 'cert-anglais',
    title: 'Formation en Langue Anglaise',
    provider: 'Maranatha\'s Center',
    location: 'Tshikapa, RDC',
    period: 'Nov. 2017 — Mai 2018',
    category: 'Langues',
    highlights: [
      'Structures grammaticales, communication orale professionnelle et lecture de documentations techniques.'
    ]
  },
  {
    id: 'cert-bureau',
    title: 'Formation en Bureautique Avancée (Word, Excel, PPT, Publisher)',
    provider: 'Cybercafé La Congolaise',
    location: 'Tshikapa, RDC',
    period: 'Févr. 2016 — Mai 2016',
    category: 'Bureautique',
    highlights: [
      'Automatisation de tableaux complexes, calculs matriciels, présentations dynamiques et édition professionnelle.'
    ]
  }
];

export const LANGUAGES_DATA = [
  { name: 'Français', level: 'Courant / Langue de travail', pct: 98, note: 'Rédaction administrative, technique & académique' },
  { name: 'Anglais', level: 'Intermédiaire Professionnel', pct: 75, note: 'Lecture technique, documentation et échange professionnel' },
  { name: 'Lingala', level: 'Courant / Langue nationale', pct: 95, note: 'Communication fluide' },
  { name: 'T\'shiluba', level: 'Courant / Langue nationale', pct: 95, note: 'Communication fluide' },
  { name: 'Kikongo', level: 'Courant / Langue nationale', pct: 85, note: 'Communication fluide' },
  { name: 'Swahili', level: 'Opérationnel / Langue nationale', pct: 70, note: 'Échanges et contacts terrain' }
];

export const REFERENCES_DATA: ReferenceItem[] = [
  {
    name: 'Alphonse BELANGANAYI',
    title: 'Secrétaire Particulier',
    organization: 'Mairie de la Ville de Tshikapa',
    phone: '+243 812 929 804'
  },
  {
    name: 'Djony KASHINDIKA',
    title: 'Administrateur Général',
    organization: 'Complexe Scolaire SHAMUANA',
    phone: '+243 993 901 630'
  },
  {
    name: 'Jean-Pierre GBINI',
    title: 'Représentant Général',
    organization: 'CAMS / KIKWIT'
  },
  {
    name: 'Christian MUEPU',
    title: 'Responsable Gérant',
    organization: 'Shop Christian Tshikapa',
    phone: '+243 990 924 592'
  },
  {
    name: 'Joseph MUNTU KALAMBA',
    title: 'Coordonnateur Régional',
    organization: 'ONG ADPS / Tshikapa',
    phone: '+243 817 575 183'
  },
  {
    name: 'KALUBI JOACHIM',
    title: 'Formateur et Chef de Brigade',
    organization: 'Opération RGPH-2',
    phone: '+243 848 432 641'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-bdd-admin',
    title: 'Optimisation des bases de données relationnelles dans l\'administration publique : Enjeux et Méthodes',
    slug: 'optimisation-bases-donnees-administration-publique',
    category: 'Bases de Données & SIG',
    date: '18 Mars 2026',
    readTime: '6 min',
    summary: 'Comment structurer, indexer et sécuriser les registres administratifs pour passer du papier à un système d\'information fiable et rapide.',
    tags: ['Bases de données', 'SQL', 'Administration', 'Gouvernance des données'],
    keyTakeaways: [
      'Une modélisation relationnelle rigoureuse en 3ème forme normale élimine plus de 90% des redondances.',
      'L\'indexation ciblée des clés de recherche transforme les requêtes de plusieurs minutes en réponses instantanées.',
      'L\'accompagnement des agents municipaux est aussi important que le code pour la durabilité du système.'
    ],
    content: [
      "Dans beaucoup d'institutions territoriales, le volume documentaire croît de manière exponentielle chaque mois. Sans architecture de données adéquate, la recherche d'un simple acte de naissance ou d'une autorisation administrative peut rapidement se transformer en un casse-tête de plusieurs heures.",
      "Durant mes interventions à la Mairie de Tshikapa et au C.S. Shamuana, j'ai constaté qu'un système d'information efficace repose sur trois piliers indissociables :",
      "1. La normalisation du schéma de données : En évitant la redondance des informations par une découpe rationnelle des entités (citoyens, actes, dates, agents), on protège la base contre les incohérences lors des mises à jour.",
      "2. Les politiques de sauvegarde automatisées : Une administration ne peut pas se permettre de perdre des registres. La mise en place de sauvegardes différentielles quotidiennes et d'un archivage miroir sur support externe garantit la résilience.",
      "3. L'accessibilité ergonomique : Un système informatique doit être conçu pour ses utilisateurs finaux. En intégrant des interfaces de saisie assistée avec contrôles de validation immédiats, on prévient les erreurs à la source.",
      "La transformation numérique des administrations publiques n'est pas un luxe, c'est le socle de la transparence et de l'efficacité envers les citoyens."
    ]
  },
  {
    id: 'post-cybersecurite-pme',
    title: 'Sécurité informatique et tests d\'intrusion : Pourquoi chaque PME doit auditer son réseau',
    slug: 'cybersecurite-tests-intrusion-pme',
    category: 'Cybersécurité',
    date: '2 Février 2026',
    readTime: '5 min',
    summary: 'Les vecteurs d\'attaque les plus fréquents rencontrés sur le terrain et les gestes de cyberdéfense indispensables pour protéger ses données.',
    tags: ['Cybersécurité', 'Hacking Éthique', 'Réseau', 'Audit'],
    keyTakeaways: [
      'Plus de 80% des intrusions exploitent des mots de passe par défaut ou des ports ouverts inutiles.',
      'Le chiffrement des communications et des disques de sauvegarde est la meilleure assurance contre le vol.',
      'Le hacking éthique permet de corriger les failles avant qu\'un tiers malveillant ne s\'y engouffre.'
    ],
    content: [
      "La cybersécurité n'est plus un sujet réservé aux grandes multinationales ou aux banques. Les petites et moyennes structures, les commerces et les ONG gèrent chaque jour des données confidentielles, des registres comptables et des coordonnées de partenaires.",
      "Lors de ma formation certifiante chez Cyberbox à Kinshasa, nous avons analysé des cas récents d'attaques : dans la majorité des incidents, l'assaillant ne passe pas par des logiciels sophistiqués, mais par une faille humaine ou une configuration par défaut oubliée.",
      "Pour durcir la sécurité d'une structure locale :",
      "• Segmenter le réseau Wi-Fi : Isoler impérativement le réseau des visiteurs du réseau professionnel où transitent les fichiers comptables.",
      "• Auditer régulièrement les vulnérabilités avec des outils comme Nmap ou Wireshark pour repérer les terminaux connectés suspects.",
      "• Mettre en place l'authentification multi-facteurs (2FA) sur tous les accès critiques (messageries, serveurs distants, comptes cloud).",
      "Adopter une posture de défense préventive coûte infiniment moins cher que de subir un arrêt d'activité consécutif à une perte irrémédiable de données."
    ]
  },
  {
    id: 'post-cartographie-rgph',
    title: 'Cartographie numérique et SIG : Les coulisses du découpage territorial pour le RGPH-2',
    slug: 'cartographie-numerique-sig-rgph',
    category: 'Bases de Données & SIG',
    date: '14 Janvier 2026',
    readTime: '7 min',
    summary: 'Retour d\'expérience sur la création de bases de sondage d\'unités aréolaires et la délimitation précise des aires de dénombrement.',
    tags: ['SIG', 'Cartographie', 'RGPH', 'Géoréférencement'],
    keyTakeaways: [
      'Le géoréférencement exhaustif des infrastructures conditionne la justesse des politiques publiques de santé et d\'éducation.',
      'La délimitation d\'aires de dénombrement homogènes permet aux agents de terrain de couvrir 100% des habitations.',
      'L\'alliance des outils GPS modernes avec la connaissance terrain élimine les zones d\'ombre.'
    ],
    content: [
      "Comment s'assurer que chaque famille, chaque hameau et chaque infrastructure soient correctement recensés dans un pays de la dimension de la RDC ? C'est tout le défi des Opérateurs Cartographes du RGPH-2.",
      "Sur le terrain, la rigueur est absolue. Chaque repère doit être géolocalisé : écoles, centres de santé, points d'eau, marchés et axes de communication.",
      "Le workflow cartographique comprend plusieurs étapes critiques :",
      "1. La reconnaissance et l'identification des limites naturelles ou artificielles (cours d'eau, ravins, grandes voies).",
      "2. La délimitation d'unités aréolaires équilibrées : chaque agent recenseur doit recevoir une aire claire, délimitée sans chevauchement ni omission.",
      "3. L'intégration dans le SIG centralisé : chaque point relevé est injecté dans la base spatiale avec ses métadonnées (nom local, type d'infrastructure, état).",
      "Une cartographie fiable, c'est la garantie que l'État et ses partenaires orienteront leurs futurs investissements là où les besoins sont les plus urgents."
    ]
  },
  {
    id: 'post-maintenance-mobile',
    title: 'Diagnostic de cartes mères et flash de firmware : L\'art du dépannage électronique mobile',
    slug: 'diagnostic-cartes-meres-flash-firmware-mobile',
    category: 'Hardware & Électronique',
    date: '19 Décembre 2025',
    readTime: '6 min',
    summary: 'Méthodologie pour diagnostiquer les pannes matérielles au composant et restaurer les systèmes d\'exploitation des smartphones.',
    tags: ['Hardware', 'Électronique', 'Décodage', 'Mobile'],
    keyTakeaways: [
      'Un examen minutieux à la loupe thermique ou au multimètre résout 60% des pannes d\'allumage inexpliquées.',
      'Le flash de firmware requiert l\'exacte correspondance du SKU et de la région pour éviter le hard-brick.',
      'Comprendre l\'architecture des processeurs mobiles (MediaTek, Qualcomm, Unisoc) accélère le diagnostic.'
    ],
    content: [
      "Durant mes années de gestion technique chez Shop Christian et ma spécialisation avec ALC&LGS au Bénin, j'ai vu défiler des centaines d'appareils déclarés 'irrécupérables' par des ateliers non outillés.",
      "La maintenance mobile moderne exige à la fois de la rigueur électronique et une connaissance pointue des micro-logiciels :",
      "• Du côté matériel : Maîtriser le circuit de charge (PMIC), les résistances shunt et les condensateurs en court-circuit. Très souvent, une simple surtension sur le port USB met une ligne d'alimentation en sécurité.",
      "• Du côté logiciel : Distinguer un bootloop lié à une partition système corrompue d'une panne eMMC/UFS défaillante. L'utilisation d'outils officiels de flashage avec les algorithmes adéquats permet de sauver des appareils bloqués tout en préservant l'intégrité du matériel.",
      "Cette double compétence hardware-software est un atout précieux dans des contextes où le renouvellement systématique d'appareils coûteux n'est pas viable."
    ]
  },
  {
    id: 'post-tracabilite-logistique',
    title: 'Digitalisation des flux logistiques : De la feuille papier au tableau de bord automatisé',
    slug: 'digitalisation-flux-logistiques-adps',
    category: 'Logistique & Gestion',
    date: '8 Novembre 2025',
    readTime: '5 min',
    summary: 'Comment l\'informatique transforme la chaîne d\'approvisionnement d\'une organisation humanitaire ou commerciale.',
    tags: ['Logistique', 'Automatisation', 'Bases de données', 'Productivité'],
    keyTakeaways: [
      'L\'automatisation des inventaires réduit les écarts de stock de plus de 95%.',
      'Des alertes de réapprovisionnement programmées évitent les ruptures critiques de matériel.',
      'Un bon système logistique donne aux décideurs une visibilité en temps réel sur les actifs déployés.'
    ],
    content: [
      "Au sein d'une organisation comme l'ONG ADPS, chaque équipement informatique, chaque fourniture ou pièce de rechange a une destination précise et critique pour les opérations.",
      "Tenir la logistique sur de simples carnets papier expose inévitablement à des pertes, des doublons ou des retards dans l'exécution des missions.",
      "En concevant des bases de données logistiques personnalisées, nous avons pu :",
      "1. Assigner un identifiant unique traçable à chaque actif dès son entrée en stock.",
      "2. Établir des fiches de mouvement automatiques avec signature numérique de réception.",
      "3. Fournir à la direction des rapports consolidés en un clic, facilitant les audits des bailleurs et partenaires institutionnels.",
      "L'informatique n'est pas une simple couche bureautique : c'est le catalyseur qui rend l'action logistique fluide, transparente et pérenne."
    ]
  }
];
